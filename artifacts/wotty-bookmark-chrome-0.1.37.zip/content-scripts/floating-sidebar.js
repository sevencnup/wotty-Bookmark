var floatingSidebar=(function(){"use strict";var $=Object.defineProperty;var W=(u,a,m)=>a in u?$(u,a,{enumerable:!0,configurable:!0,writable:!0,value:m}):u[a]=m;var p=(u,a,m)=>W(u,typeof a!="symbol"?a+"":a,m);var x,A,c,T,l;const a=(A=(x=globalThis.browser)==null?void 0:x.runtime)!=null&&A.id?globalThis.browser:globalThis.chrome;function m(e){return e}const w="wotty-bookmark-floating-sidebar",N="wotty-bookmark:toggle-floating-sidebar",M="wotty-bookmark:sidebar-activity",R=5e3,P=`
:host {
  all: initial !important;
  position: fixed !important;
  inset: 0 !important;
  z-index: 2147483647 !important;
  display: block !important;
  width: 100vw !important;
  height: 100vh !important;
  margin: 0 !important;
  padding: 0 !important;
  border: 0 !important;
  pointer-events: none !important;
  --wotty-sidebar-width: min(390px, calc(100vw - 48px));
}

*, *::before, *::after { box-sizing: border-box; }

.panel {
  position: absolute;
  top: 0;
  right: 0;
  width: var(--wotty-sidebar-width);
  height: 100vh;
  height: 100dvh;
  overflow: hidden;
  border-left: 1px solid #dbe4f0;
  background: #f8fafc;
  box-shadow: -14px 0 36px rgba(15, 23, 42, 0.2);
  opacity: 0;
  pointer-events: none;
  transform: translateX(100%);
  visibility: hidden;
  transition: transform 220ms cubic-bezier(0.16, 1, 0.3, 1), opacity 160ms ease, visibility 0s linear 220ms;
}

:host([data-open='true']) .panel {
  opacity: 1;
  pointer-events: auto;
  transform: translateX(0);
  visibility: visible;
  transition: transform 220ms cubic-bezier(0.16, 1, 0.3, 1), opacity 160ms ease, visibility 0s;
}

.panel iframe {
  display: block;
  width: 100%;
  height: 100%;
  border: 0;
  background: #f8fafc;
}

.edge-toggle {
  position: absolute;
  top: 50%;
  right: 6px;
  display: grid;
  width: 42px;
  height: 42px;
  place-items: center;
  padding: 0;
  border: 2px solid #ffffff;
  border-radius: 50%;
  color: #ffffff;
  background: #2563eb;
  box-shadow: 0 0 0 1px rgba(37, 99, 235, 0.38), 0 5px 18px rgba(15, 23, 42, 0.3);
  backdrop-filter: blur(10px);
  cursor: pointer;
  pointer-events: auto;
  transform: translateY(-50%);
  transition: right 220ms cubic-bezier(0.16, 1, 0.3, 1), transform 160ms ease, background 160ms ease, box-shadow 160ms ease;
}

.edge-toggle:hover {
  background: #1d4ed8;
  box-shadow: 0 0 0 2px rgba(37, 99, 235, 0.28), 0 7px 22px rgba(15, 23, 42, 0.34);
  transform: translateY(-50%) scale(1.06);
}

.edge-toggle:focus-visible {
  outline: 3px solid #93c5fd;
  outline-offset: -4px;
}

:host([data-open='true']) .edge-toggle {
  right: 6px;
  border-color: #ffffff;
  color: #1d4ed8;
  background: #fff;
  box-shadow: 0 0 0 1px rgba(37, 99, 235, 0.3), 0 5px 16px rgba(15, 23, 42, 0.2);
}

.edge-toggle svg {
  width: 21px;
  height: 21px;
  fill: none;
  stroke: currentColor;
  stroke-linecap: round;
  stroke-linejoin: round;
  stroke-width: 2;
}

@media (prefers-reduced-motion: reduce) {
  .panel, .edge-toggle { transition: none; }
}
`,B={matches:["http://*/*","https://*/*"],runAt:"document_idle",main(e){if(document.getElementById(w))return;const t=document.createElement("wotty-bookmark-floating-sidebar");t.id=w,t.style.cssText="all:initial!important;position:fixed!important;inset:0!important;z-index:2147483647!important;display:block!important;width:100vw!important;height:100vh!important;margin:0!important;padding:0!important;border:0!important;pointer-events:none!important;";const i=t.attachShadow({mode:"closed"}),o=document.createElement("style");o.textContent=P;const r=document.createElement("aside");r.className="panel",r.id="wotty-bookmark-floating-panel",r.setAttribute("role","complementary"),r.setAttribute("aria-label","\u4E66\u7B7E\u4FA7\u680F"),r.setAttribute("aria-hidden","true");const d=document.createElement("iframe");d.title="\u4E66\u7B7E\u4FA7\u680F",d.setAttribute("loading","eager"),r.append(d);const s=document.createElement("button");s.className="edge-toggle",s.type="button",s.setAttribute("aria-controls",r.id),s.setAttribute("aria-expanded","false"),s.setAttribute("aria-label","\u5C55\u5F00\u4E66\u7B7E\u4FA7\u680F"),s.title="\u5C55\u5F00\u4E66\u7B7E\u4FA7\u680F",s.innerHTML='<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M7.5 3.75h9A1.75 1.75 0 0 1 18.25 5.5V21l-6.25-4-6.25 4V5.5A1.75 1.75 0 0 1 7.5 3.75Z" /></svg>',i.append(o,r,s),document.documentElement.append(t);let E=!1,y=!1,f;const v=()=>{window.clearTimeout(f),E&&(f=window.setTimeout(()=>C(!1,document.activeElement===t),R))},C=(n,Y=!0)=>{E=n,window.clearTimeout(f),t.dataset.open=String(n),s.setAttribute("aria-expanded",String(n)),s.setAttribute("aria-label",n?"\u6536\u8D77\u4E66\u7B7E\u4FA7\u680F":"\u5C55\u5F00\u4E66\u7B7E\u4FA7\u680F"),s.title=n?"\u6536\u8D77\u4E66\u7B7E\u4FA7\u680F":"\u5C55\u5F00\u4E66\u7B7E\u4FA7\u680F",r.setAttribute("aria-hidden",String(!n)),d.inert=!n,n&&!y&&(y=!0,d.src=a.runtime.getURL("/sidebar-frame.html")),n?v():Y&&s.focus({preventScroll:!0})},I=()=>C(!E),k=n=>{typeof n=="object"&&n!==null&&"type"in n&&n.type===N&&I()},L=n=>{n.source===d.contentWindow&&typeof n.data=="object"&&n.data!==null&&"type"in n.data&&n.data.type===M&&v()},F=n=>{n.composedPath().includes(t)&&v()},_=["pointerdown","pointermove","keydown","wheel","touchstart","input","change","scroll"];_.forEach(n=>window.addEventListener(n,F,{capture:!0,passive:!0})),s.addEventListener("click",I),a.runtime.onMessage.addListener(k),window.addEventListener("message",L),e.onInvalidated(()=>{window.clearTimeout(f),_.forEach(n=>window.removeEventListener(n,F,!0)),window.removeEventListener("message",L),a.runtime.onMessage.removeListener(k),t.remove()})}};function h(e,...t){}const D={debug:(...e)=>h(console.debug,...e),log:(...e)=>h(console.log,...e),warn:(...e)=>h(console.warn,...e),error:(...e)=>h(console.error,...e)};var S=(c=class extends Event{constructor(t,i){super(c.EVENT_NAME,{}),this.newUrl=t,this.oldUrl=i}},p(c,"EVENT_NAME",b("wxt:locationchange")),c);function b(e){var t;return`${(t=a==null?void 0:a.runtime)==null?void 0:t.id}:floating-sidebar:${e}`}const U=typeof((T=globalThis.navigation)==null?void 0:T.addEventListener)=="function";function G(e){let t,i=!1;return{run(){i||(i=!0,t=new URL(location.href),U?globalThis.navigation.addEventListener("navigate",o=>{const r=new URL(o.destination.url);r.href!==t.href&&(window.dispatchEvent(new S(r,t)),t=r)},{signal:e.signal}):e.setInterval(()=>{const o=new URL(location.href);o.href!==t.href&&(window.dispatchEvent(new S(o,t)),t=o)},1e3))}}}var O=(l=class{constructor(t,i){p(this,"id");p(this,"abortController");p(this,"locationWatcher",G(this));this.contentScriptName=t,this.options=i,this.id=Math.random().toString(36).slice(2),this.abortController=new AbortController,this.stopOldScripts(),this.listenForNewerScripts()}get signal(){return this.abortController.signal}abort(t){return this.abortController.abort(t)}get isInvalid(){var t;return((t=a.runtime)==null?void 0:t.id)==null&&this.notifyInvalidated(),this.signal.aborted}get isValid(){return!this.isInvalid}onInvalidated(t){return this.signal.addEventListener("abort",t),()=>this.signal.removeEventListener("abort",t)}block(){return new Promise(()=>{})}setInterval(t,i){const o=setInterval(()=>{this.isValid&&t()},i);return this.onInvalidated(()=>clearInterval(o)),o}setTimeout(t,i){const o=setTimeout(()=>{this.isValid&&t()},i);return this.onInvalidated(()=>clearTimeout(o)),o}requestAnimationFrame(t){const i=requestAnimationFrame((...o)=>{this.isValid&&t(...o)});return this.onInvalidated(()=>cancelAnimationFrame(i)),i}requestIdleCallback(t,i){const o=requestIdleCallback((...r)=>{this.signal.aborted||t(...r)},i);return this.onInvalidated(()=>cancelIdleCallback(o)),o}addEventListener(t,i,o,r){var d;i==="wxt:locationchange"&&this.isValid&&this.locationWatcher.run(),(d=t.addEventListener)==null||d.call(t,i.startsWith("wxt:")?b(i):i,o,{...r,signal:this.signal})}notifyInvalidated(){this.abort("Content script context invalidated"),D.debug(`Content script "${this.contentScriptName}" context invalidated`)}stopOldScripts(){var t;document.dispatchEvent(new CustomEvent(l.SCRIPT_STARTED_MESSAGE_TYPE,{detail:{contentScriptName:this.contentScriptName,messageId:this.id}})),(t=this.options)!=null&&t.noScriptStartedPostMessage||window.postMessage({type:l.SCRIPT_STARTED_MESSAGE_TYPE,contentScriptName:this.contentScriptName,messageId:this.id},"*")}verifyScriptStartedEvent(t){var r,d;const i=((r=t.detail)==null?void 0:r.contentScriptName)===this.contentScriptName,o=((d=t.detail)==null?void 0:d.messageId)===this.id;return i&&!o}listenForNewerScripts(){const t=i=>{!(i instanceof CustomEvent)||!this.verifyScriptStartedEvent(i)||this.notifyInvalidated()};document.addEventListener(l.SCRIPT_STARTED_MESSAGE_TYPE,t),this.onInvalidated(()=>document.removeEventListener(l.SCRIPT_STARTED_MESSAGE_TYPE,t))}},p(l,"SCRIPT_STARTED_MESSAGE_TYPE",b("wxt:content-script-started")),l);function z(){}function g(e,...t){}const V={debug:(...e)=>g(console.debug,...e),log:(...e)=>g(console.log,...e),warn:(...e)=>g(console.warn,...e),error:(...e)=>g(console.error,...e)};return(async()=>{try{const{main:e,...t}=B;return await e(new O("floating-sidebar",t))}catch(e){throw V.error('The content script "floating-sidebar" crashed on startup!',e),e}})()})();

floatingSidebar;