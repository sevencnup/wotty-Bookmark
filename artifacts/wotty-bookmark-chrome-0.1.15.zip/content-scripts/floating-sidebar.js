var floatingSidebar=(function(){"use strict";var P=Object.defineProperty;var B=(u,o,p)=>o in u?P(u,o,{enumerable:!0,configurable:!0,writable:!0,value:p}):u[o]=p;var g=(u,o,p)=>B(u,typeof o!="symbol"?o+"":o,p);var E,w,c,S,l;const o=(w=(E=globalThis.browser)==null?void 0:E.runtime)!=null&&w.id?globalThis.browser:globalThis.chrome;function p(e){return e}const f="wotty-bookmark-floating-sidebar",C="wotty-bookmark:toggle-floating-sidebar",I=`
:host {
  all: initial !important;
  position: fixed !important;
  inset: 0 !important;
  z-index: 2147483647 !important;
  display: block !important;
  width: 100vw !important;
  height: 100vh !important;
  margin: 0 !important;
  padding: 0 !important;
  border: 0 !important;
  pointer-events: none !important;
  --wotty-sidebar-width: min(390px, calc(100vw - 24px));
}

*, *::before, *::after { box-sizing: border-box; }

.panel {
  position: absolute;
  top: 0;
  right: 0;
  width: var(--wotty-sidebar-width);
  height: 100vh;
  height: 100dvh;
  overflow: hidden;
  border-left: 1px solid #dbe4f0;
  background: #f8fafc;
  box-shadow: -14px 0 36px rgba(15, 23, 42, 0.2);
  opacity: 0;
  pointer-events: none;
  transform: translateX(100%);
  visibility: hidden;
  transition: transform 220ms cubic-bezier(0.16, 1, 0.3, 1), opacity 160ms ease, visibility 0s linear 220ms;
}

:host([data-open='true']) .panel {
  opacity: 1;
  pointer-events: auto;
  transform: translateX(0);
  visibility: visible;
  transition: transform 220ms cubic-bezier(0.16, 1, 0.3, 1), opacity 160ms ease, visibility 0s;
}

.panel iframe {
  display: block;
  width: 100%;
  height: 100%;
  border: 0;
  background: #f8fafc;
}

.edge-toggle {
  position: absolute;
  top: 50%;
  right: 0;
  display: grid;
  width: 38px;
  height: 66px;
  place-items: center;
  padding: 0;
  border: 1px solid #1d4ed8;
  border-right: 0;
  border-radius: 10px 0 0 10px;
  color: #fff;
  background: linear-gradient(180deg, #3b82f6 0%, #1d4ed8 100%);
  box-shadow: 0 5px 18px rgba(15, 23, 42, 0.24);
  cursor: pointer;
  pointer-events: auto;
  transform: translateY(-50%);
  transition: right 220ms cubic-bezier(0.16, 1, 0.3, 1), background 160ms ease, box-shadow 160ms ease;
}

.edge-toggle:hover {
  background: linear-gradient(180deg, #2563eb 0%, #1e40af 100%);
  box-shadow: 0 7px 22px rgba(15, 23, 42, 0.3);
}

.edge-toggle:focus-visible {
  outline: 3px solid #93c5fd;
  outline-offset: -4px;
}

:host([data-open='true']) .edge-toggle {
  right: var(--wotty-sidebar-width);
  color: #1d4ed8;
  background: #fff;
  box-shadow: -4px 5px 16px rgba(15, 23, 42, 0.16);
}

.edge-toggle svg {
  width: 21px;
  height: 21px;
  fill: none;
  stroke: currentColor;
  stroke-linecap: round;
  stroke-linejoin: round;
  stroke-width: 2.2;
  transition: transform 180ms ease;
}

:host([data-open='true']) .edge-toggle svg { transform: rotate(180deg); }

@media (prefers-reduced-motion: reduce) {
  .panel, .edge-toggle, .edge-toggle svg { transition: none; }
}
`,F={matches:["http://*/*","https://*/*"],runAt:"document_idle",main(e){if(document.getElementById(f))return;const t=document.createElement("wotty-bookmark-floating-sidebar");t.id=f,t.style.cssText="all:initial!important;position:fixed!important;inset:0!important;z-index:2147483647!important;display:block!important;width:100vw!important;height:100vh!important;margin:0!important;padding:0!important;border:0!important;pointer-events:none!important;";const i=t.attachShadow({mode:"closed"}),n=document.createElement("style");n.textContent=I;const r=document.createElement("aside");r.className="panel",r.id="wotty-bookmark-floating-panel",r.setAttribute("role","complementary"),r.setAttribute("aria-label","\u4E66\u7B7E\u4FA7\u680F"),r.setAttribute("aria-hidden","true");const d=document.createElement("iframe");d.title="\u4E66\u7B7E\u4FA7\u680F",d.setAttribute("loading","eager"),r.append(d);const s=document.createElement("button");s.className="edge-toggle",s.type="button",s.setAttribute("aria-controls",r.id),s.setAttribute("aria-expanded","false"),s.setAttribute("aria-label","\u5C55\u5F00\u4E66\u7B7E\u4FA7\u680F"),s.title="\u5C55\u5F00\u4E66\u7B7E\u4FA7\u680F",s.innerHTML='<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m14.5 5-7 7 7 7" /></svg>',i.append(n,r,s),document.documentElement.append(t);let x=!1,A=!1;const M=a=>{x=a,t.dataset.open=String(a),s.setAttribute("aria-expanded",String(a)),s.setAttribute("aria-label",a?"\u6536\u8D77\u4E66\u7B7E\u4FA7\u680F":"\u5C55\u5F00\u4E66\u7B7E\u4FA7\u680F"),s.title=a?"\u6536\u8D77\u4E66\u7B7E\u4FA7\u680F":"\u5C55\u5F00\u4E66\u7B7E\u4FA7\u680F",r.setAttribute("aria-hidden",String(!a)),d.inert=!a,a&&!A&&(A=!0,d.src=o.runtime.getURL("/sidebar-frame.html")),a||s.focus({preventScroll:!0})},T=()=>M(!x),y=a=>{typeof a=="object"&&a!==null&&"type"in a&&a.type===C&&T()};s.addEventListener("click",T),o.runtime.onMessage.addListener(y),e.onInvalidated(()=>{o.runtime.onMessage.removeListener(y),t.remove()})}};function h(e,...t){}const k={debug:(...e)=>h(console.debug,...e),log:(...e)=>h(console.log,...e),warn:(...e)=>h(console.warn,...e),error:(...e)=>h(console.error,...e)};var v=(c=class extends Event{constructor(t,i){super(c.EVENT_NAME,{}),this.newUrl=t,this.oldUrl=i}},g(c,"EVENT_NAME",b("wxt:locationchange")),c);function b(e){var t;return`${(t=o==null?void 0:o.runtime)==null?void 0:t.id}:floating-sidebar:${e}`}const L=typeof((S=globalThis.navigation)==null?void 0:S.addEventListener)=="function";function N(e){let t,i=!1;return{run(){i||(i=!0,t=new URL(location.href),L?globalThis.navigation.addEventListener("navigate",n=>{const r=new URL(n.destination.url);r.href!==t.href&&(window.dispatchEvent(new v(r,t)),t=r)},{signal:e.signal}):e.setInterval(()=>{const n=new URL(location.href);n.href!==t.href&&(window.dispatchEvent(new v(n,t)),t=n)},1e3))}}}var _=(l=class{constructor(t,i){g(this,"id");g(this,"abortController");g(this,"locationWatcher",N(this));this.contentScriptName=t,this.options=i,this.id=Math.random().toString(36).slice(2),this.abortController=new AbortController,this.stopOldScripts(),this.listenForNewerScripts()}get signal(){return this.abortController.signal}abort(t){return this.abortController.abort(t)}get isInvalid(){var t;return((t=o.runtime)==null?void 0:t.id)==null&&this.notifyInvalidated(),this.signal.aborted}get isValid(){return!this.isInvalid}onInvalidated(t){return this.signal.addEventListener("abort",t),()=>this.signal.removeEventListener("abort",t)}block(){return new Promise(()=>{})}setInterval(t,i){const n=setInterval(()=>{this.isValid&&t()},i);return this.onInvalidated(()=>clearInterval(n)),n}setTimeout(t,i){const n=setTimeout(()=>{this.isValid&&t()},i);return this.onInvalidated(()=>clearTimeout(n)),n}requestAnimationFrame(t){const i=requestAnimationFrame((...n)=>{this.isValid&&t(...n)});return this.onInvalidated(()=>cancelAnimationFrame(i)),i}requestIdleCallback(t,i){const n=requestIdleCallback((...r)=>{this.signal.aborted||t(...r)},i);return this.onInvalidated(()=>cancelIdleCallback(n)),n}addEventListener(t,i,n,r){var d;i==="wxt:locationchange"&&this.isValid&&this.locationWatcher.run(),(d=t.addEventListener)==null||d.call(t,i.startsWith("wxt:")?b(i):i,n,{...r,signal:this.signal})}notifyInvalidated(){this.abort("Content script context invalidated"),k.debug(`Content script "${this.contentScriptName}" context invalidated`)}stopOldScripts(){var t;document.dispatchEvent(new CustomEvent(l.SCRIPT_STARTED_MESSAGE_TYPE,{detail:{contentScriptName:this.contentScriptName,messageId:this.id}})),(t=this.options)!=null&&t.noScriptStartedPostMessage||window.postMessage({type:l.SCRIPT_STARTED_MESSAGE_TYPE,contentScriptName:this.contentScriptName,messageId:this.id},"*")}verifyScriptStartedEvent(t){var r,d;const i=((r=t.detail)==null?void 0:r.contentScriptName)===this.contentScriptName,n=((d=t.detail)==null?void 0:d.messageId)===this.id;return i&&!n}listenForNewerScripts(){const t=i=>{!(i instanceof CustomEvent)||!this.verifyScriptStartedEvent(i)||this.notifyInvalidated()};document.addEventListener(l.SCRIPT_STARTED_MESSAGE_TYPE,t),this.onInvalidated(()=>document.removeEventListener(l.SCRIPT_STARTED_MESSAGE_TYPE,t))}},g(l,"SCRIPT_STARTED_MESSAGE_TYPE",b("wxt:content-script-started")),l);function U(){}function m(e,...t){}const R={debug:(...e)=>m(console.debug,...e),log:(...e)=>m(console.log,...e),warn:(...e)=>m(console.warn,...e),error:(...e)=>m(console.error,...e)};return(async()=>{try{const{main:e,...t}=F;return await e(new _("floating-sidebar",t))}catch(e){throw R.error('The content script "floating-sidebar" crashed on startup!',e),e}})()})();

floatingSidebar;