var floatingSidebar=(function(){"use strict";var It=Object.defineProperty;var Lt=(m,d,v)=>d in m?It(m,d,{enumerable:!0,configurable:!0,writable:!0,value:v}):m[d]=v;var f=(m,d,v)=>Lt(m,typeof d!="symbol"?d+"":d,v);var H,U,h,$,c;const d=(U=(H=globalThis.browser)==null?void 0:H.runtime)!=null&&U.id?globalThis.browser:globalThis.chrome;function v(i){return i}const G="wotty-bookmark-floating-sidebar",ct="wotty-bookmark:toggle-floating-sidebar",pt="wotty-bookmark:sidebar-activity",gt=5e3,B="bookmark-vault.floating-sidebar-width.v1",P="bookmark-vault.floating-sidebar-toggle-position.v1",O=390,ht=280,mt=44,bt=.5,Et=34,Y=8,ft=4,vt=`
:host {
  all: initial !important;
  position: fixed !important;
  inset: 0 !important;
  z-index: 2147483647 !important;
  display: block !important;
  width: 100vw !important;
  height: 100vh !important;
  margin: 0 !important;
  padding: 0 !important;
  border: 0 !important;
  pointer-events: none !important;
  --wotty-sidebar-width: min(390px, calc(100vw - 44px));
  --wotty-toggle-top: 50%;
}

*, *::before, *::after { box-sizing: border-box; }

.panel {
  position: absolute;
  top: 0;
  right: 0;
  width: var(--wotty-sidebar-width);
  height: 100vh;
  height: 100dvh;
  overflow: hidden;
  border-left: 1px solid #dbe4f0;
  background: #f8fafc;
  box-shadow: -14px 0 36px rgba(15, 23, 42, 0.2);
  opacity: 0;
  pointer-events: none;
  transform: translateX(100%);
  visibility: hidden;
  transition: transform 220ms cubic-bezier(0.16, 1, 0.3, 1), opacity 160ms ease, visibility 0s linear 220ms;
}

:host([data-open='true']) .panel {
  opacity: 1;
  pointer-events: auto;
  transform: translateX(0);
  visibility: visible;
  transition: transform 220ms cubic-bezier(0.16, 1, 0.3, 1), opacity 160ms ease, visibility 0s;
}

.panel iframe {
  display: block;
  width: 100%;
  height: 100%;
  border: 0;
  background: #f8fafc;
}

.resize-handle {
  position: absolute;
  top: 0;
  right: calc(var(--wotty-sidebar-width) - 4px);
  z-index: 1;
  width: 8px;
  height: 100vh;
  height: 100dvh;
  cursor: col-resize;
  opacity: 0;
  pointer-events: none;
  touch-action: none;
  transition: opacity 160ms ease;
}

.resize-handle::after {
  position: absolute;
  top: 50%;
  left: 2px;
  width: 3px;
  height: 44px;
  border-radius: 999px;
  background: #cbd5e1;
  box-shadow: 0 0 0 1px rgba(255, 255, 255, 0.9), 0 1px 5px rgba(15, 23, 42, 0.16);
  content: '';
  transform: translateY(-50%);
  transition: background 160ms ease, box-shadow 160ms ease, transform 160ms ease;
}

:host([data-open='true']) .resize-handle {
  opacity: 0.6;
  pointer-events: auto;
}

.resize-handle:hover,
:host([data-resizing='true']) .resize-handle {
  opacity: 1;
}

.resize-handle:hover::after,
:host([data-resizing='true']) .resize-handle::after {
  background: #2563eb;
  box-shadow: 0 0 0 1px #ffffff, 0 2px 8px rgba(37, 99, 235, 0.38);
  transform: translateY(-50%) scaleY(1.18);
}

.resize-handle:focus-visible::after {
  background: #2563eb;
  box-shadow: 0 0 0 3px #bfdbfe;
}

.edge-toggle {
  position: absolute;
  top: var(--wotty-toggle-top);
  right: 5px;
  display: grid;
  width: 34px;
  height: 34px;
  place-items: center;
  padding: 0;
  border: 1px solid #ffffff;
  border-radius: 50%;
  background: rgba(255, 255, 255, 0.98);
  box-shadow: 0 0 0 1px rgba(37, 99, 235, 0.42), 0 4px 12px rgba(15, 23, 42, 0.26);
  backdrop-filter: blur(10px);
  cursor: pointer;
  pointer-events: auto;
  touch-action: none;
  user-select: none;
  transform: translateY(-50%);
  transition: right 220ms cubic-bezier(0.16, 1, 0.3, 1), transform 160ms ease, background 160ms ease, box-shadow 160ms ease;
}

.edge-toggle:hover {
  background: #eff6ff;
  box-shadow: 0 0 0 2px rgba(37, 99, 235, 0.2), 0 6px 16px rgba(15, 23, 42, 0.3);
  transform: translateY(-50%) scale(1.08);
}

.edge-toggle:focus-visible {
  outline: 3px solid #93c5fd;
  outline-offset: -4px;
}

:host([data-open='true']) .edge-toggle {
  right: 5px;
  background: #eff6ff;
  box-shadow: 0 0 0 1px rgba(37, 99, 235, 0.46), 0 4px 12px rgba(15, 23, 42, 0.24);
}

:host([data-positioning='true']) .edge-toggle {
  cursor: grabbing;
  transform: translateY(-50%);
  transition: none;
}

.edge-toggle img {
  display: block;
  width: 25px;
  height: 25px;
  object-fit: contain;
  pointer-events: none;
}

@media (prefers-reduced-motion: reduce) {
  .panel, .resize-handle, .resize-handle::after, .edge-toggle { transition: none; }
}
`,wt={matches:["http://*/*","https://*/*"],runAt:"document_idle",main(i){if(document.getElementById(G))return;const e=document.createElement("wotty-bookmark-floating-sidebar");e.id=G,e.style.cssText="all:initial!important;position:fixed!important;inset:0!important;z-index:2147483647!important;display:block!important;width:100vw!important;height:100vh!important;margin:0!important;padding:0!important;border:0!important;pointer-events:none!important;";const o=e.attachShadow({mode:"closed"}),s=document.createElement("style");s.textContent=vt;const u=document.createElement("aside");u.className="panel",u.id="wotty-bookmark-floating-panel",u.setAttribute("role","complementary"),u.setAttribute("aria-label","\u4E66\u7B7E\u4FA7\u680F"),u.setAttribute("aria-hidden","true");const l=document.createElement("iframe");l.title="\u4E66\u7B7E\u4FA7\u680F",l.setAttribute("loading","eager"),l.inert=!0,l.src=d.runtime.getURL("/sidebar-frame.html"),u.append(l);const n=document.createElement("div");n.className="resize-handle",n.setAttribute("aria-hidden","true"),n.setAttribute("aria-label","\u8C03\u6574\u4E66\u7B7E\u4FA7\u680F\u5BBD\u5EA6"),n.setAttribute("aria-orientation","vertical"),n.setAttribute("role","separator"),n.tabIndex=-1,n.title="\u62D6\u52A8\u8C03\u6574\u4FA7\u680F\u5BBD\u5EA6\uFF1B\u53CC\u51FB\u6062\u590D\u9ED8\u8BA4\u5BBD\u5EA6";const r=document.createElement("button");r.className="edge-toggle",r.type="button",r.setAttribute("aria-controls",u.id),r.setAttribute("aria-expanded","false"),r.setAttribute("aria-label","\u5C55\u5F00\u4E66\u7B7E\u4FA7\u680F\uFF1B\u53EF\u4E0A\u4E0B\u62D6\u52A8\u8C03\u6574\u4F4D\u7F6E"),r.title="\u5C55\u5F00\u4E66\u7B7E\u4FA7\u680F\uFF1B\u53EF\u4E0A\u4E0B\u62D6\u52A8\u8C03\u6574\u4F4D\u7F6E";const R=document.createElement("img");R.alt="",R.src=d.runtime.getURL("/logo.webp"),r.append(R),o.append(s,u,n,r),document.documentElement.append(e);let T=!1,F,b=O,y,w=bt,I,V=0,x=!1,L=!1;const M=()=>{const t=Math.max(1,window.innerWidth-mt);return{min:Math.min(ht,t),max:t}},q=t=>{const{min:a,max:p}=M();return Math.min(p,Math.max(a,Math.round(t)))},C=()=>{const t=q(b);e.style.setProperty("--wotty-sidebar-width",`${t}px`);const{min:a,max:p}=M();n.setAttribute("aria-valuemin",String(a)),n.setAttribute("aria-valuemax",String(p)),n.setAttribute("aria-valuenow",String(t))},j=()=>{d.storage.local.set({[B]:b}).catch(()=>{})},N=(t,a=!1)=>{b=q(t),C(),a&&j()},yt=()=>{const t=Et/2,a=Math.min(window.innerHeight/2,t+Y),p=Math.max(a,window.innerHeight-t-Y);return{min:a/Math.max(1,window.innerHeight),max:p/Math.max(1,window.innerHeight)}},K=t=>{const{min:a,max:p}=yt();return Math.min(p,Math.max(a,t))},D=()=>{const t=K(w);e.style.setProperty("--wotty-toggle-top",`${t*100}%`)},X=(t,a=!1)=>{w=K(t),D(),a&&d.storage.local.set({[P]:w}).catch(()=>{})};C(),d.storage.local.get(B).then(t=>{const a=t[B];typeof a=="number"&&Number.isFinite(a)&&(b=a),C()}).catch(()=>{}),D(),d.storage.local.get(P).then(t=>{const a=t[P];typeof a=="number"&&Number.isFinite(a)&&(w=a),D()}).catch(()=>{});const g=()=>{window.clearTimeout(F),T&&(F=window.setTimeout(()=>J(!1,document.activeElement===e),gt))},J=(t,a=!0)=>{T=t,window.clearTimeout(F),e.dataset.open=String(t),r.setAttribute("aria-expanded",String(t)),r.setAttribute("aria-label",t?"\u6536\u8D77\u4E66\u7B7E\u4FA7\u680F\uFF1B\u53EF\u4E0A\u4E0B\u62D6\u52A8\u8C03\u6574\u4F4D\u7F6E":"\u5C55\u5F00\u4E66\u7B7E\u4FA7\u680F\uFF1B\u53EF\u4E0A\u4E0B\u62D6\u52A8\u8C03\u6574\u4F4D\u7F6E"),r.title=t?"\u6536\u8D77\u4E66\u7B7E\u4FA7\u680F\uFF1B\u53EF\u4E0A\u4E0B\u62D6\u52A8\u8C03\u6574\u4F4D\u7F6E":"\u5C55\u5F00\u4E66\u7B7E\u4FA7\u680F\uFF1B\u53EF\u4E0A\u4E0B\u62D6\u52A8\u8C03\u6574\u4F4D\u7F6E",u.setAttribute("aria-hidden",String(!t)),l.inert=!t,n.setAttribute("aria-hidden",String(!t)),n.tabIndex=t?0:-1,t?g():a&&r.focus({preventScroll:!0})},Q=()=>J(!T),Z=t=>{typeof t=="object"&&t!==null&&"type"in t&&t.type===ct&&Q()},tt=t=>{t.source===l.contentWindow&&typeof t.data=="object"&&t.data!==null&&"type"in t.data&&t.data.type===pt&&g()},et=t=>{t.composedPath().includes(e)&&g()},it=t=>{!T||t.button!==0||(t.preventDefault(),y=t.pointerId,n.setPointerCapture(t.pointerId),e.dataset.resizing="true",g())},nt=t=>{y===t.pointerId&&(N(window.innerWidth-t.clientX),g())},k=t=>{y===t.pointerId&&(n.hasPointerCapture(t.pointerId)&&n.releasePointerCapture(t.pointerId),y=void 0,delete e.dataset.resizing,j())},ot=t=>{const{min:a,max:p}=M();let E;t.key==="ArrowLeft"&&(E=b+20),t.key==="ArrowRight"&&(E=b-20),t.key==="Home"&&(E=a),t.key==="End"&&(E=p),E!==void 0&&(t.preventDefault(),N(E,!0),g())},rt=()=>N(O,!0),at=t=>{t.button===0&&(t.preventDefault(),I=t.pointerId,V=t.clientY,x=!1,r.setPointerCapture(t.pointerId),g())},st=t=>{I===t.pointerId&&(!x&&Math.abs(t.clientY-V)<ft||(x=!0,e.dataset.positioning="true",X(t.clientY/Math.max(1,window.innerHeight)),g()))},_=t=>{I===t.pointerId&&(r.hasPointerCapture(t.pointerId)&&r.releasePointerCapture(t.pointerId),I=void 0,x&&(X(w,!0),L=!0,window.setTimeout(()=>{L=!1},0)),x=!1,delete e.dataset.positioning)},dt=t=>{if(L){t.preventDefault(),t.stopPropagation(),L=!1;return}Q()},ut=()=>{C(),D()},lt=["pointerdown","pointermove","keydown","wheel","touchstart","input","change","scroll"];lt.forEach(t=>window.addEventListener(t,et,{capture:!0,passive:!0})),r.addEventListener("pointerdown",at),r.addEventListener("pointermove",st),r.addEventListener("pointerup",_),r.addEventListener("pointercancel",_),r.addEventListener("click",dt),n.addEventListener("pointerdown",it),n.addEventListener("pointermove",nt),n.addEventListener("pointerup",k),n.addEventListener("pointercancel",k),n.addEventListener("keydown",ot),n.addEventListener("dblclick",rt),d.runtime.onMessage.addListener(Z),window.addEventListener("message",tt),window.addEventListener("resize",ut),i.onInvalidated(()=>{window.clearTimeout(F),lt.forEach(t=>window.removeEventListener(t,et,!0)),r.removeEventListener("pointerdown",at),r.removeEventListener("pointermove",st),r.removeEventListener("pointerup",_),r.removeEventListener("pointercancel",_),r.removeEventListener("click",dt),n.removeEventListener("pointerdown",it),n.removeEventListener("pointermove",nt),n.removeEventListener("pointerup",k),n.removeEventListener("pointercancel",k),n.removeEventListener("keydown",ot),n.removeEventListener("dblclick",rt),window.removeEventListener("message",tt),window.removeEventListener("resize",ut),d.runtime.onMessage.removeListener(Z),e.remove()})}};function A(i,...e){}const xt={debug:(...i)=>A(console.debug,...i),log:(...i)=>A(console.log,...i),warn:(...i)=>A(console.warn,...i),error:(...i)=>A(console.error,...i)};var W=(h=class extends Event{constructor(e,o){super(h.EVENT_NAME,{}),this.newUrl=e,this.oldUrl=o}},f(h,"EVENT_NAME",z("wxt:locationchange")),h);function z(i){var e;return`${(e=d==null?void 0:d.runtime)==null?void 0:e.id}:floating-sidebar:${i}`}const At=typeof(($=globalThis.navigation)==null?void 0:$.addEventListener)=="function";function St(i){let e,o=!1;return{run(){o||(o=!0,e=new URL(location.href),At?globalThis.navigation.addEventListener("navigate",s=>{const u=new URL(s.destination.url);u.href!==e.href&&(window.dispatchEvent(new W(u,e)),e=u)},{signal:i.signal}):i.setInterval(()=>{const s=new URL(location.href);s.href!==e.href&&(window.dispatchEvent(new W(s,e)),e=s)},1e3))}}}var Tt=(c=class{constructor(e,o){f(this,"id");f(this,"abortController");f(this,"locationWatcher",St(this));this.contentScriptName=e,this.options=o,this.id=Math.random().toString(36).slice(2),this.abortController=new AbortController,this.stopOldScripts(),this.listenForNewerScripts()}get signal(){return this.abortController.signal}abort(e){return this.abortController.abort(e)}get isInvalid(){var e;return((e=d.runtime)==null?void 0:e.id)==null&&this.notifyInvalidated(),this.signal.aborted}get isValid(){return!this.isInvalid}onInvalidated(e){return this.signal.addEventListener("abort",e),()=>this.signal.removeEventListener("abort",e)}block(){return new Promise(()=>{})}setInterval(e,o){const s=setInterval(()=>{this.isValid&&e()},o);return this.onInvalidated(()=>clearInterval(s)),s}setTimeout(e,o){const s=setTimeout(()=>{this.isValid&&e()},o);return this.onInvalidated(()=>clearTimeout(s)),s}requestAnimationFrame(e){const o=requestAnimationFrame((...s)=>{this.isValid&&e(...s)});return this.onInvalidated(()=>cancelAnimationFrame(o)),o}requestIdleCallback(e,o){const s=requestIdleCallback((...u)=>{this.signal.aborted||e(...u)},o);return this.onInvalidated(()=>cancelIdleCallback(s)),s}addEventListener(e,o,s,u){var l;o==="wxt:locationchange"&&this.isValid&&this.locationWatcher.run(),(l=e.addEventListener)==null||l.call(e,o.startsWith("wxt:")?z(o):o,s,{...u,signal:this.signal})}notifyInvalidated(){this.abort("Content script context invalidated"),xt.debug(`Content script "${this.contentScriptName}" context invalidated`)}stopOldScripts(){var e;document.dispatchEvent(new CustomEvent(c.SCRIPT_STARTED_MESSAGE_TYPE,{detail:{contentScriptName:this.contentScriptName,messageId:this.id}})),(e=this.options)!=null&&e.noScriptStartedPostMessage||window.postMessage({type:c.SCRIPT_STARTED_MESSAGE_TYPE,contentScriptName:this.contentScriptName,messageId:this.id},"*")}verifyScriptStartedEvent(e){var u,l;const o=((u=e.detail)==null?void 0:u.contentScriptName)===this.contentScriptName,s=((l=e.detail)==null?void 0:l.messageId)===this.id;return o&&!s}listenForNewerScripts(){const e=o=>{!(o instanceof CustomEvent)||!this.verifyScriptStartedEvent(o)||this.notifyInvalidated()};document.addEventListener(c.SCRIPT_STARTED_MESSAGE_TYPE,e),this.onInvalidated(()=>document.removeEventListener(c.SCRIPT_STARTED_MESSAGE_TYPE,e))}},f(c,"SCRIPT_STARTED_MESSAGE_TYPE",z("wxt:content-script-started")),c);function Ct(){}function S(i,...e){}const Ft={debug:(...i)=>S(console.debug,...i),log:(...i)=>S(console.log,...i),warn:(...i)=>S(console.warn,...i),error:(...i)=>S(console.error,...i)};return(async()=>{try{const{main:i,...e}=wt;return await i(new Tt("floating-sidebar",e))}catch(i){throw Ft.error('The content script "floating-sidebar" crashed on startup!',i),i}})()})();

floatingSidebar;