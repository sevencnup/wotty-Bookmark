var floatingSidebar=(function(){"use strict";var Ke=Object.defineProperty;var Xe=(v,d,S)=>d in v?Ke(v,d,{enumerable:!0,configurable:!0,writable:!0,value:S}):v[d]=S;var x=(v,d,S)=>Xe(v,typeof d!="symbol"?d+"":d,S);var re,ie,E,oe,p;const d=(ie=(re=globalThis.browser)==null?void 0:re.runtime)!=null&&ie.id?globalThis.browser:globalThis.chrome;function S(r){return r}const Q="wotty-bookmark-floating-sidebar",Z="0.1.67-motion-1",De="wotty-bookmark:toggle-floating-sidebar",Be="wotty-bookmark:sidebar-activity",Ce="wotty-bookmark:sidebar-ready",ke=5e3,$="bookmark-vault.floating-sidebar-width.v1",V="bookmark-vault.floating-sidebar-toggle-position.v1",ee=390,_e=280,Pe=44,Re=.5,Me=34,te=8,ze=14,Oe=4,Ne=`
:host {
  all: initial !important;
  position: fixed !important;
  inset: 0 !important;
  z-index: 2147483647 !important;
  display: block !important;
  width: 100vw !important;
  height: 100vh !important;
  margin: 0 !important;
  padding: 0 !important;
  border: 0 !important;
  pointer-events: none !important;
  overflow: clip !important;
  --wotty-sidebar-width: min(390px, calc(100vw - 44px));
  --wotty-toggle-top: 50%;
  --wotty-scrollbar-width: 0px;
}

*, *::before, *::after { box-sizing: border-box; }

.panel {
  position: absolute;
  top: 0;
  right: 0;
  width: var(--wotty-sidebar-width);
  height: 100vh;
  height: 100dvh;
  overflow: hidden;
  border-left: 1px solid #dbe4f0;
  background: #f8fafc;
  box-shadow: -14px 0 36px rgba(15, 23, 42, 0.2);
  pointer-events: none;
  transform: translate3d(calc(100% + 48px), 0, 0);
  transition: transform 210ms cubic-bezier(0.25, 1, 0.5, 1);
  will-change: transform;
}

:host([data-open='true']) .panel {
  transform: translate3d(0, 0, 0);
  transition-duration: 280ms;
  pointer-events: auto;
}

.panel iframe {
  display: block;
  width: 100%;
  height: 100%;
  border: 0;
  background: #f8fafc;
}

.frame-placeholder {
  position: absolute;
  inset: 0;
  z-index: 2;
  display: grid;
  align-content: center;
  justify-items: center;
  gap: 10px;
  background: #f8fafc;
  color: #475569;
  font: 13px/1.5 -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
}

.frame-placeholder-spinner {
  width: 22px;
  height: 22px;
  border: 2px solid #bfdbfe;
  border-top-color: #2563eb;
  border-radius: 50%;
  animation: wotty-sidebar-spin 700ms linear infinite;
}

.frame-placeholder-error {
  display: none;
  max-width: 260px;
  padding: 0 18px;
  text-align: center;
}

.frame-placeholder-retry {
  display: block;
  margin: 12px auto 0;
  padding: 7px 12px;
  border: 1px solid #bfdbfe;
  border-radius: 7px;
  background: #ffffff;
  color: #1d4ed8;
  cursor: pointer;
}

.panel[data-frame-error='true'] .frame-placeholder-spinner,
.panel[data-frame-error='true'] .frame-placeholder-message {
  display: none;
}

.panel[data-frame-error='true'] .frame-placeholder-error { display: block; }
.panel[data-frame-ready='true'] .frame-placeholder { display: none; }

@keyframes wotty-sidebar-spin { to { transform: rotate(360deg); } }

.resize-handle {
  position: absolute;
  top: 0;
  right: calc(var(--wotty-sidebar-width) - 4px);
  z-index: 1;
  width: 8px;
  height: 100vh;
  height: 100dvh;
  cursor: col-resize;
  opacity: 0;
  pointer-events: none;
  touch-action: none;
  transform: translate3d(calc(var(--wotty-sidebar-width) + 48px), 0, 0);
  transition: transform 210ms cubic-bezier(0.25, 1, 0.5, 1), opacity 160ms ease;
}

.resize-handle::after {
  position: absolute;
  top: 50%;
  left: 2px;
  width: 3px;
  height: 44px;
  border-radius: 999px;
  background: #cbd5e1;
  box-shadow: 0 0 0 1px rgba(255, 255, 255, 0.9), 0 1px 5px rgba(15, 23, 42, 0.16);
  content: '';
  transform: translateY(-50%);
  transition: background 160ms ease, box-shadow 160ms ease, transform 160ms ease;
}

:host([data-open='true']) .resize-handle {
  transform: translate3d(0, 0, 0);
  transition-duration: 280ms, 160ms;
  opacity: 0.6;
  pointer-events: auto;
}

.resize-handle:hover,
:host([data-resizing='true']) .resize-handle {
  opacity: 1;
}

.resize-handle:hover::after,
:host([data-resizing='true']) .resize-handle::after {
  background: #2563eb;
  box-shadow: 0 0 0 1px #ffffff, 0 2px 8px rgba(37, 99, 235, 0.38);
  transform: translateY(-50%) scaleY(1.18);
}

.resize-handle:focus-visible::after {
  background: #2563eb;
  box-shadow: 0 0 0 3px #bfdbfe;
}

.edge-toggle {
  position: absolute;
  top: var(--wotty-toggle-top);
  right: calc(5px + var(--wotty-scrollbar-width));
  display: grid;
  width: 34px;
  height: 34px;
  place-items: center;
  padding: 0;
  border: 1px solid #ffffff;
  border-radius: 50%;
  background: rgba(255, 255, 255, 0.98);
  box-shadow: 0 0 0 1px rgba(37, 99, 235, 0.42), 0 4px 12px rgba(15, 23, 42, 0.26);
  cursor: pointer;
  opacity: 0;
  pointer-events: auto;
  touch-action: none;
  user-select: none;
  visibility: hidden;
  transform: translateY(-50%);
  transition: right 220ms cubic-bezier(0.16, 1, 0.3, 1), transform 160ms ease, background 160ms ease, box-shadow 160ms ease, opacity 120ms ease;
}

:host([data-toggle-ready='true']) .edge-toggle {
  opacity: 1;
  visibility: visible;
}

.edge-toggle:hover {
  background: #eff6ff;
  box-shadow: 0 0 0 2px rgba(37, 99, 235, 0.2), 0 6px 16px rgba(15, 23, 42, 0.3);
  transform: translateY(-50%) scale(1.08);
}

.edge-toggle:focus-visible {
  outline: 3px solid #93c5fd;
  outline-offset: -4px;
}

:host([data-open='true']) .edge-toggle {
  right: calc(5px + var(--wotty-scrollbar-width));
  background: #eff6ff;
  box-shadow: 0 0 0 1px rgba(37, 99, 235, 0.46), 0 4px 12px rgba(15, 23, 42, 0.24);
}

:host([data-positioning='true']) .edge-toggle {
  cursor: grabbing;
  transform: translateY(-50%);
  transition: none;
}

.edge-toggle img {
  display: block;
  width: 25px;
  height: 25px;
  object-fit: contain;
  pointer-events: none;
}

@media (prefers-reduced-motion: reduce) {
  .panel, .resize-handle, .resize-handle::after, .edge-toggle { transition: none; }
}
`,Ge={matches:["http://*/*","https://*/*"],runAt:"document_idle",main(r){const t=document.getElementById(Q);if((t==null?void 0:t.dataset.build)===Z)return;const a=(t==null?void 0:t.dataset.open)==="true"||document.documentElement.getAttribute("data-wotty-sidebar-restore-open")==="true";document.documentElement.removeAttribute("data-wotty-sidebar-restore-open"),t==null||t.remove();const n=document.createElement("wotty-bookmark-floating-sidebar");n.id=Q,n.dataset.build=Z,n.style.cssText="all:initial!important;position:fixed!important;inset:0!important;z-index:2147483647!important;display:block!important;width:100vw!important;height:100vh!important;margin:0!important;padding:0!important;border:0!important;pointer-events:none!important;";const l=n.attachShadow({mode:"closed"}),h=document.createElement("style");h.textContent=Ne;const u=document.createElement("aside");u.className="panel",u.id="wotty-bookmark-floating-panel",u.setAttribute("role","complementary"),u.setAttribute("aria-label","\u4E66\u7B7E\u4FA7\u680F"),u.setAttribute("aria-hidden","true");const w=document.createElement("iframe");w.title="\u4E66\u7B7E\u4FA7\u680F",w.setAttribute("loading","eager"),w.tabIndex=-1,u.append(w);const T=document.createElement("div");T.className="frame-placeholder",T.setAttribute("role","status"),T.innerHTML='<span class="frame-placeholder-spinner" aria-hidden="true"></span><span class="frame-placeholder-message">\u6B63\u5728\u52A0\u8F7D\u4E66\u7B7E\u4FA7\u680F\u2026</span><span class="frame-placeholder-error">\u4FA7\u680F\u6682\u65F6\u65E0\u6CD5\u52A0\u8F7D\u3002<button class="frame-placeholder-retry" type="button">\u91CD\u65B0\u52A0\u8F7D</button></span>',u.append(T);const i=document.createElement("div");i.className="resize-handle",i.setAttribute("aria-hidden","true"),i.setAttribute("aria-label","\u8C03\u6574\u4E66\u7B7E\u4FA7\u680F\u5BBD\u5EA6"),i.setAttribute("aria-orientation","vertical"),i.setAttribute("role","separator"),i.tabIndex=-1,i.title="\u62D6\u52A8\u8C03\u6574\u4FA7\u680F\u5BBD\u5EA6\uFF1B\u53CC\u51FB\u6062\u590D\u9ED8\u8BA4\u5BBD\u5EA6";const o=document.createElement("button");o.className="edge-toggle",o.type="button",o.setAttribute("aria-controls",u.id),o.setAttribute("aria-expanded","false"),o.setAttribute("aria-label","\u5C55\u5F00\u4E66\u7B7E\u4FA7\u680F\uFF1B\u53EF\u4E0A\u4E0B\u62D6\u52A8\u8C03\u6574\u4F4D\u7F6E"),o.title="\u5C55\u5F00\u4E66\u7B7E\u4FA7\u680F\uFF1B\u53EF\u4E0A\u4E0B\u62D6\u52A8\u8C03\u6574\u4F4D\u7F6E";const j=document.createElement("img");j.alt="",j.src=d.runtime.getURL("/logo.webp"),o.append(j),l.append(h,u,i,o),document.documentElement.append(n);let P=!1,R=!1,m=!1,ae=!1,A,I=!1,M,Ve=0;const qe=d.runtime.getURL("/sidebar-frame.html");let z,F=ee,O,L=Re,N,se=0,D=!1,G=!1,B;const K=()=>{const e=Math.max(1,window.innerWidth-Pe);return{min:Math.min(_e,e),max:e}},de=e=>{const{min:s,max:c}=K();return Math.min(c,Math.max(s,Math.round(e)))},W=()=>{const e=de(F);n.style.setProperty("--wotty-sidebar-width",`${e}px`);const{min:s,max:c}=K();i.setAttribute("aria-valuemin",String(s)),i.setAttribute("aria-valuemax",String(c)),i.setAttribute("aria-valuenow",String(e))},X=()=>{const e=document.documentElement,s=Math.max(0,window.innerWidth-e.clientWidth),c=e.scrollHeight>e.clientHeight,b=s||(c?ze:0);n.style.setProperty("--wotty-scrollbar-width",`${b}px`)},ue=()=>{B===void 0&&(B=window.requestAnimationFrame(()=>{B=void 0,X()}))},le=()=>{d.storage.local.set({[$]:F}).catch(()=>{})},J=(e,s=!1)=>{F=de(e),W(),s&&le()},je=()=>{const e=Me/2,s=Math.min(window.innerHeight/2,e+te),c=Math.max(s,window.innerHeight-e-te);return{min:s/Math.max(1,window.innerHeight),max:c/Math.max(1,window.innerHeight)}},ce=e=>{const{min:s,max:c}=je();return Math.min(c,Math.max(s,e))},Y=()=>{const e=ce(L);n.style.setProperty("--wotty-toggle-top",`${e*100}%`)},pe=(e,s=!1)=>{L=ce(e),Y(),s&&d.storage.local.set({[V]:L}).catch(()=>{})};W(),X(),d.storage.local.get($).then(e=>{const s=e[$];typeof s=="number"&&Number.isFinite(s)&&(F=s),W()}).catch(()=>{}),d.storage.local.get(V).then(e=>{const s=e[V];typeof s=="number"&&Number.isFinite(s)&&(L=s),Y()}).catch(()=>Y()).finally(()=>{window.requestAnimationFrame(()=>{n.dataset.toggleReady="true"})});const g=()=>{window.clearTimeout(z),P&&(z=window.setTimeout(()=>C(!1,document.activeElement===n),ke))},C=(e,s=!0)=>{P=e,window.clearTimeout(z),n.dataset.open=String(e),o.setAttribute("aria-expanded",String(e)),o.setAttribute("aria-label",e?"\u6536\u8D77\u4E66\u7B7E\u4FA7\u680F\uFF1B\u53EF\u4E0A\u4E0B\u62D6\u52A8\u8C03\u6574\u4F4D\u7F6E":"\u5C55\u5F00\u4E66\u7B7E\u4FA7\u680F\uFF1B\u53EF\u4E0A\u4E0B\u62D6\u52A8\u8C03\u6574\u4F4D\u7F6E"),o.title=e?"\u6536\u8D77\u4E66\u7B7E\u4FA7\u680F\uFF1B\u53EF\u4E0A\u4E0B\u62D6\u52A8\u8C03\u6574\u4F4D\u7F6E":"\u5C55\u5F00\u4E66\u7B7E\u4FA7\u680F\uFF1B\u53EF\u4E0A\u4E0B\u62D6\u52A8\u8C03\u6574\u4F4D\u7F6E",u.setAttribute("aria-hidden",String(!e)),w.tabIndex=e?0:-1,i.setAttribute("aria-hidden",String(!e)),i.tabIndex=e?0:-1,e?g():s&&o.focus({preventScroll:!0})},me=()=>{A!==void 0&&window.cancelAnimationFrame(A),A=void 0,I=!1,delete n.dataset.preparingOpen},fe=()=>{if(ae){C(!0);return}I||(I=!0,n.dataset.preparingOpen="true",A=window.requestAnimationFrame(()=>{A=window.requestAnimationFrame(()=>{A=void 0,I=!1,delete n.dataset.preparingOpen,ae=!0,C(!0)})}))},he=()=>{if(P){m=!1,C(!1);return}if(I){me();return}if(!R){m=!m,o.setAttribute("aria-expanded","false"),o.setAttribute("aria-label",m?"\u6B63\u5728\u51C6\u5907\u4E66\u7B7E\u4FA7\u680F\uFF1B\u518D\u6B21\u70B9\u51FB\u53D6\u6D88":"\u5C55\u5F00\u4E66\u7B7E\u4FA7\u680F\uFF1B\u53EF\u4E0A\u4E0B\u62D6\u52A8\u8C03\u6574\u4F4D\u7F6E"),o.title=m?"\u6B63\u5728\u51C6\u5907\u4E66\u7B7E\u4FA7\u680F\uFF1B\u518D\u6B21\u70B9\u51FB\u53D6\u6D88":"\u5C55\u5F00\u4E66\u7B7E\u4FA7\u680F\uFF1B\u53EF\u4E0A\u4E0B\u62D6\u52A8\u8C03\u6574\u4F4D\u7F6E";return}fe()},ge=e=>{typeof e=="object"&&e!==null&&"type"in e&&e.type===De&&he()},be=e=>{if(e.source===w.contentWindow&&!(typeof e.data!="object"||e.data===null||!("type"in e.data))){if(e.data.type===Ce){R=!0,window.clearTimeout(M),u.dataset.frameReady="true",delete u.dataset.frameError,m&&(m=!1,fe());return}e.data.type===Be&&g()}},Ee=()=>{R=!1,delete u.dataset.frameReady,delete u.dataset.frameError,window.clearTimeout(M),M=window.setTimeout(()=>{R||(u.dataset.frameError="true",m&&(m=!1,C(!0)))},8e3),w.src=`${qe}?load=${++Ve}`};T.addEventListener("click",e=>{e.target.closest(".frame-placeholder-retry")&&Ee()});const we=e=>{e.composedPath().includes(n)&&g()},ve=e=>{!P||e.button!==0||(e.preventDefault(),O=e.pointerId,i.setPointerCapture(e.pointerId),n.dataset.resizing="true",g())},Ae=e=>{O===e.pointerId&&(J(window.innerWidth-e.clientX),g())},U=e=>{O===e.pointerId&&(i.hasPointerCapture(e.pointerId)&&i.releasePointerCapture(e.pointerId),O=void 0,delete n.dataset.resizing,le())},Fe=e=>{const{min:s,max:c}=K();let b;e.key==="ArrowLeft"&&(b=F+20),e.key==="ArrowRight"&&(b=F-20),e.key==="Home"&&(b=s),e.key==="End"&&(b=c),b!==void 0&&(e.preventDefault(),J(b,!0),g())},ye=()=>J(ee,!0),xe=e=>{e.button===0&&(e.preventDefault(),N=e.pointerId,se=e.clientY,D=!1,o.setPointerCapture(e.pointerId),g())},Se=e=>{N===e.pointerId&&(!D&&Math.abs(e.clientY-se)<Oe||(D=!0,n.dataset.positioning="true",pe(e.clientY/Math.max(1,window.innerHeight)),g()))},H=e=>{N===e.pointerId&&(o.hasPointerCapture(e.pointerId)&&o.releasePointerCapture(e.pointerId),N=void 0,D&&(pe(L,!0),G=!0,window.setTimeout(()=>{G=!1},0)),D=!1,delete n.dataset.positioning)},Te=e=>{if(G){e.preventDefault(),e.stopPropagation(),G=!1;return}he()},Ie=()=>{W(),Y(),X()},f=typeof ResizeObserver>"u"?void 0:new ResizeObserver(ue);f==null||f.observe(document.documentElement),document.body&&(f==null||f.observe(document.body));const y=typeof MutationObserver>"u"?void 0:new MutationObserver(ue);document.body&&(y==null||y.observe(document.body,{childList:!0,subtree:!0})),a&&(m=!0);const Le=["pointerdown","pointermove","keydown","wheel","touchstart","input","change","scroll"];Le.forEach(e=>window.addEventListener(e,we,{capture:!0,passive:!0})),o.addEventListener("pointerdown",xe),o.addEventListener("pointermove",Se),o.addEventListener("pointerup",H),o.addEventListener("pointercancel",H),o.addEventListener("click",Te),i.addEventListener("pointerdown",ve),i.addEventListener("pointermove",Ae),i.addEventListener("pointerup",U),i.addEventListener("pointercancel",U),i.addEventListener("keydown",Fe),i.addEventListener("dblclick",ye),d.runtime.onMessage.addListener(ge),window.addEventListener("message",be),Ee(),window.addEventListener("resize",Ie),r.onInvalidated(()=>{window.clearTimeout(z),window.clearTimeout(M),me(),Le.forEach(e=>window.removeEventListener(e,we,!0)),o.removeEventListener("pointerdown",xe),o.removeEventListener("pointermove",Se),o.removeEventListener("pointerup",H),o.removeEventListener("pointercancel",H),o.removeEventListener("click",Te),i.removeEventListener("pointerdown",ve),i.removeEventListener("pointermove",Ae),i.removeEventListener("pointerup",U),i.removeEventListener("pointercancel",U),i.removeEventListener("keydown",Fe),i.removeEventListener("dblclick",ye),window.removeEventListener("message",be),window.removeEventListener("resize",Ie),f==null||f.disconnect(),y==null||y.disconnect(),B!==void 0&&window.cancelAnimationFrame(B),d.runtime.onMessage.removeListener(ge),n.remove()})}};function k(r,...t){}const We={debug:(...r)=>k(console.debug,...r),log:(...r)=>k(console.log,...r),warn:(...r)=>k(console.warn,...r),error:(...r)=>k(console.error,...r)};var ne=(E=class extends Event{constructor(t,a){super(E.EVENT_NAME,{}),this.newUrl=t,this.oldUrl=a}},x(E,"EVENT_NAME",q("wxt:locationchange")),E);function q(r){var t;return`${(t=d==null?void 0:d.runtime)==null?void 0:t.id}:floating-sidebar:${r}`}const Ye=typeof((oe=globalThis.navigation)==null?void 0:oe.addEventListener)=="function";function Ue(r){let t,a=!1;return{run(){a||(a=!0,t=new URL(location.href),Ye?globalThis.navigation.addEventListener("navigate",n=>{const l=new URL(n.destination.url);l.href!==t.href&&(window.dispatchEvent(new ne(l,t)),t=l)},{signal:r.signal}):r.setInterval(()=>{const n=new URL(location.href);n.href!==t.href&&(window.dispatchEvent(new ne(n,t)),t=n)},1e3))}}}var He=(p=class{constructor(t,a){x(this,"id");x(this,"abortController");x(this,"locationWatcher",Ue(this));this.contentScriptName=t,this.options=a,this.id=Math.random().toString(36).slice(2),this.abortController=new AbortController,this.stopOldScripts(),this.listenForNewerScripts()}get signal(){return this.abortController.signal}abort(t){return this.abortController.abort(t)}get isInvalid(){var t;return((t=d.runtime)==null?void 0:t.id)==null&&this.notifyInvalidated(),this.signal.aborted}get isValid(){return!this.isInvalid}onInvalidated(t){return this.signal.addEventListener("abort",t),()=>this.signal.removeEventListener("abort",t)}block(){return new Promise(()=>{})}setInterval(t,a){const n=setInterval(()=>{this.isValid&&t()},a);return this.onInvalidated(()=>clearInterval(n)),n}setTimeout(t,a){const n=setTimeout(()=>{this.isValid&&t()},a);return this.onInvalidated(()=>clearTimeout(n)),n}requestAnimationFrame(t){const a=requestAnimationFrame((...n)=>{this.isValid&&t(...n)});return this.onInvalidated(()=>cancelAnimationFrame(a)),a}requestIdleCallback(t,a){const n=requestIdleCallback((...l)=>{this.signal.aborted||t(...l)},a);return this.onInvalidated(()=>cancelIdleCallback(n)),n}addEventListener(t,a,n,l){var h;a==="wxt:locationchange"&&this.isValid&&this.locationWatcher.run(),(h=t.addEventListener)==null||h.call(t,a.startsWith("wxt:")?q(a):a,n,{...l,signal:this.signal})}notifyInvalidated(){this.abort("Content script context invalidated"),We.debug(`Content script "${this.contentScriptName}" context invalidated`)}stopOldScripts(){var t;document.dispatchEvent(new CustomEvent(p.SCRIPT_STARTED_MESSAGE_TYPE,{detail:{contentScriptName:this.contentScriptName,messageId:this.id}})),(t=this.options)!=null&&t.noScriptStartedPostMessage||window.postMessage({type:p.SCRIPT_STARTED_MESSAGE_TYPE,contentScriptName:this.contentScriptName,messageId:this.id},"*")}verifyScriptStartedEvent(t){var l,h;const a=((l=t.detail)==null?void 0:l.contentScriptName)===this.contentScriptName,n=((h=t.detail)==null?void 0:h.messageId)===this.id;return a&&!n}listenForNewerScripts(){const t=a=>{!(a instanceof CustomEvent)||!this.verifyScriptStartedEvent(a)||this.notifyInvalidated()};document.addEventListener(p.SCRIPT_STARTED_MESSAGE_TYPE,t),this.onInvalidated(()=>document.removeEventListener(p.SCRIPT_STARTED_MESSAGE_TYPE,t))}},x(p,"SCRIPT_STARTED_MESSAGE_TYPE",q("wxt:content-script-started")),p);function Je(){}function _(r,...t){}const $e={debug:(...r)=>_(console.debug,...r),log:(...r)=>_(console.log,...r),warn:(...r)=>_(console.warn,...r),error:(...r)=>_(console.error,...r)};return(async()=>{try{const{main:r,...t}=Ge;return await r(new He("floating-sidebar",t))}catch(r){throw $e.error('The content script "floating-sidebar" crashed on startup!',r),r}})()})();

floatingSidebar;