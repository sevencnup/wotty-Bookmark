var floatingSidebar=(function(){"use strict";var Vt=Object.defineProperty;var qt=(w,d,x)=>d in w?Vt(w,d,{enumerable:!0,configurable:!0,writable:!0,value:x}):w[d]=x;var A=(w,d,x)=>qt(w,typeof d!="symbol"?d+"":d,x);var et,nt,E,ot,m;const d=(nt=(et=globalThis.browser)==null?void 0:et.runtime)!=null&&nt.id?globalThis.browser:globalThis.chrome;function x(r){return r}const K="wotty-bookmark-floating-sidebar",Q="0.1.67-frame-api-3",Ft="wotty-bookmark:toggle-floating-sidebar",Tt="wotty-bookmark:sidebar-activity",It="wotty-bookmark:sidebar-ready",Lt="wotty-bookmark:frame-api-request",X="wotty-bookmark:frame-api-response",kt=5e3,W="bookmark-vault.floating-sidebar-width.v1",O="bookmark-vault.floating-sidebar-toggle-position.v1",J=390,Ct=280,Dt=44,_t=.5,Bt=34,Z=8,Rt=14,Pt=4,Mt=`
:host {
  all: initial !important;
  position: fixed !important;
  inset: 0 !important;
  z-index: 2147483647 !important;
  display: block !important;
  width: 100vw !important;
  height: 100vh !important;
  margin: 0 !important;
  padding: 0 !important;
  border: 0 !important;
  pointer-events: none !important;
  overflow: clip !important;
  --wotty-sidebar-width: min(390px, calc(100vw - 44px));
  --wotty-toggle-top: 50%;
  --wotty-scrollbar-width: 0px;
}

*, *::before, *::after { box-sizing: border-box; }

.panel {
  position: absolute;
  top: 0;
  right: 0;
  width: var(--wotty-sidebar-width);
  height: 100vh;
  height: 100dvh;
  overflow: hidden;
  border-left: 1px solid #dbe4f0;
  background: #f8fafc;
  box-shadow: -14px 0 36px rgba(15, 23, 42, 0.2);
  pointer-events: none;
  transform: translate3d(calc(100% + 48px), 0, 0);
  transition: transform 210ms cubic-bezier(0.25, 1, 0.5, 1);
  will-change: transform;
}

:host([data-open='true']) .panel {
  transform: translate3d(0, 0, 0);
  transition-duration: 280ms;
  pointer-events: auto;
}

.panel iframe {
  display: block;
  width: 100%;
  height: 100%;
  border: 0;
  background: #f8fafc;
}

.frame-placeholder {
  position: absolute;
  inset: 0;
  z-index: 2;
  display: grid;
  align-content: center;
  justify-items: center;
  gap: 10px;
  background: #f8fafc;
  color: #475569;
  font: 13px/1.5 -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
}

.frame-placeholder-spinner {
  width: 22px;
  height: 22px;
  border: 2px solid #bfdbfe;
  border-top-color: #2563eb;
  border-radius: 50%;
  animation: wotty-sidebar-spin 700ms linear infinite;
}

.frame-placeholder-error {
  display: none;
  max-width: 260px;
  padding: 0 18px;
  text-align: center;
}

.frame-placeholder-retry {
  display: block;
  margin: 12px auto 0;
  padding: 7px 12px;
  border: 1px solid #bfdbfe;
  border-radius: 7px;
  background: #ffffff;
  color: #1d4ed8;
  cursor: pointer;
}

.panel[data-frame-error='true'] .frame-placeholder-spinner,
.panel[data-frame-error='true'] .frame-placeholder-message {
  display: none;
}

.panel[data-frame-error='true'] .frame-placeholder-error { display: block; }
.panel[data-frame-ready='true'] .frame-placeholder { display: none; }

@keyframes wotty-sidebar-spin { to { transform: rotate(360deg); } }

.resize-handle {
  position: absolute;
  top: 0;
  right: calc(var(--wotty-sidebar-width) - 4px);
  z-index: 1;
  width: 8px;
  height: 100vh;
  height: 100dvh;
  cursor: col-resize;
  opacity: 0;
  pointer-events: none;
  touch-action: none;
  transform: translate3d(calc(var(--wotty-sidebar-width) + 48px), 0, 0);
  transition: transform 210ms cubic-bezier(0.25, 1, 0.5, 1), opacity 160ms ease;
}

.resize-handle::after {
  position: absolute;
  top: 50%;
  left: 2px;
  width: 3px;
  height: 44px;
  border-radius: 999px;
  background: #cbd5e1;
  box-shadow: 0 0 0 1px rgba(255, 255, 255, 0.9), 0 1px 5px rgba(15, 23, 42, 0.16);
  content: '';
  transform: translateY(-50%);
  transition: background 160ms ease, box-shadow 160ms ease, transform 160ms ease;
}

:host([data-open='true']) .resize-handle {
  transform: translate3d(0, 0, 0);
  transition-duration: 280ms, 160ms;
  opacity: 0.6;
  pointer-events: auto;
}

.resize-handle:hover,
:host([data-resizing='true']) .resize-handle {
  opacity: 1;
}

.resize-handle:hover::after,
:host([data-resizing='true']) .resize-handle::after {
  background: #2563eb;
  box-shadow: 0 0 0 1px #ffffff, 0 2px 8px rgba(37, 99, 235, 0.38);
  transform: translateY(-50%) scaleY(1.18);
}

.resize-handle:focus-visible::after {
  background: #2563eb;
  box-shadow: 0 0 0 3px #bfdbfe;
}

.edge-toggle {
  position: absolute;
  top: var(--wotty-toggle-top);
  right: calc(5px + var(--wotty-scrollbar-width));
  display: grid;
  width: 34px;
  height: 34px;
  place-items: center;
  padding: 0;
  border: 1px solid #ffffff;
  border-radius: 50%;
  background: rgba(255, 255, 255, 0.98);
  box-shadow: 0 0 0 1px rgba(37, 99, 235, 0.42), 0 4px 12px rgba(15, 23, 42, 0.26);
  cursor: pointer;
  opacity: 0;
  pointer-events: auto;
  touch-action: none;
  user-select: none;
  visibility: hidden;
  transform: translateY(-50%);
  transition: right 220ms cubic-bezier(0.16, 1, 0.3, 1), transform 160ms ease, background 160ms ease, box-shadow 160ms ease, opacity 120ms ease;
}

:host([data-toggle-ready='true']) .edge-toggle {
  opacity: 1;
  visibility: visible;
}

.edge-toggle:hover {
  background: #eff6ff;
  box-shadow: 0 0 0 2px rgba(37, 99, 235, 0.2), 0 6px 16px rgba(15, 23, 42, 0.3);
  transform: translateY(-50%) scale(1.08);
}

.edge-toggle:focus-visible {
  outline: 3px solid #93c5fd;
  outline-offset: -4px;
}

:host([data-open='true']) .edge-toggle {
  right: calc(5px + var(--wotty-scrollbar-width));
  background: #eff6ff;
  box-shadow: 0 0 0 1px rgba(37, 99, 235, 0.46), 0 4px 12px rgba(15, 23, 42, 0.24);
}

:host([data-positioning='true']) .edge-toggle {
  cursor: grabbing;
  transform: translateY(-50%);
  transition: none;
}

.edge-toggle img {
  display: block;
  width: 25px;
  height: 25px;
  object-fit: contain;
  pointer-events: none;
}

@media (prefers-reduced-motion: reduce) {
  .panel, .resize-handle, .resize-handle::after, .edge-toggle { transition: none; }
}
`,zt={matches:["http://*/*","https://*/*"],runAt:"document_idle",main(r){const e=document.getElementById(K);if((e==null?void 0:e.dataset.build)===Q)return;const a=(e==null?void 0:e.dataset.open)==="true"||document.documentElement.getAttribute("data-wotty-sidebar-restore-open")==="true";document.documentElement.removeAttribute("data-wotty-sidebar-restore-open"),e==null||e.remove();const n=document.createElement("wotty-bookmark-floating-sidebar");n.id=K,n.dataset.build=Q,n.style.cssText="all:initial!important;position:fixed!important;inset:0!important;z-index:2147483647!important;display:block!important;width:100vw!important;height:100vh!important;margin:0!important;padding:0!important;border:0!important;pointer-events:none!important;";const p=n.attachShadow({mode:"closed"}),g=document.createElement("style");g.textContent=Mt;const u=document.createElement("aside");u.className="panel",u.id="wotty-bookmark-floating-panel",u.setAttribute("role","complementary"),u.setAttribute("aria-label","\u4E66\u7B7E\u4FA7\u680F"),u.setAttribute("aria-hidden","true");const h=document.createElement("iframe");h.title="\u4E66\u7B7E\u4FA7\u680F",h.setAttribute("loading","eager"),h.tabIndex=-1,u.append(h);const S=document.createElement("div");S.className="frame-placeholder",S.setAttribute("role","status"),S.innerHTML='<span class="frame-placeholder-spinner" aria-hidden="true"></span><span class="frame-placeholder-message">\u6B63\u5728\u52A0\u8F7D\u4E66\u7B7E\u4FA7\u680F\u2026</span><span class="frame-placeholder-error">\u4FA7\u680F\u6682\u65F6\u65E0\u6CD5\u52A0\u8F7D\u3002<button class="frame-placeholder-retry" type="button">\u91CD\u65B0\u52A0\u8F7D</button></span>',u.append(S);const i=document.createElement("div");i.className="resize-handle",i.setAttribute("aria-hidden","true"),i.setAttribute("aria-label","\u8C03\u6574\u4E66\u7B7E\u4FA7\u680F\u5BBD\u5EA6"),i.setAttribute("aria-orientation","vertical"),i.setAttribute("role","separator"),i.tabIndex=-1,i.title="\u62D6\u52A8\u8C03\u6574\u4FA7\u680F\u5BBD\u5EA6\uFF1B\u53CC\u51FB\u6062\u590D\u9ED8\u8BA4\u5BBD\u5EA6";const s=document.createElement("button");s.className="edge-toggle",s.type="button",s.setAttribute("aria-controls",u.id),s.setAttribute("aria-expanded","false"),s.setAttribute("aria-label","\u5C55\u5F00\u4E66\u7B7E\u4FA7\u680F\uFF1B\u53EF\u4E0A\u4E0B\u62D6\u52A8\u8C03\u6574\u4F4D\u7F6E"),s.title="\u5C55\u5F00\u4E66\u7B7E\u4FA7\u680F\uFF1B\u53EF\u4E0A\u4E0B\u62D6\u52A8\u8C03\u6574\u4F4D\u7F6E";const U=document.createElement("img");U.alt="",U.src=d.runtime.getURL("/logo.webp"),s.append(U),p.append(g,u,i,s),document.documentElement.append(n);let C=!1,H=!1,D,Ut=0;const rt=d.runtime.getURL("/sidebar-frame.html"),Ht=new URL(rt).origin;let _,v=J,B,F=_t,R,it=0,T=!1,P=!1,I;const $=()=>{const t=Math.max(1,window.innerWidth-Dt);return{min:Math.min(Ct,t),max:t}},at=t=>{const{min:o,max:l}=$();return Math.min(l,Math.max(o,Math.round(t)))},M=()=>{const t=at(v);n.style.setProperty("--wotty-sidebar-width",`${t}px`);const{min:o,max:l}=$();i.setAttribute("aria-valuemin",String(o)),i.setAttribute("aria-valuemax",String(l)),i.setAttribute("aria-valuenow",String(t))},V=()=>{const t=document.documentElement,o=Math.max(0,window.innerWidth-t.clientWidth),l=t.scrollHeight>t.clientHeight,c=o||(l?Rt:0);n.style.setProperty("--wotty-scrollbar-width",`${c}px`)},st=()=>{I===void 0&&(I=window.requestAnimationFrame(()=>{I=void 0,V()}))},dt=()=>{d.storage.local.set({[W]:v}).catch(()=>{})},q=(t,o=!1)=>{v=at(t),M(),o&&dt()},$t=()=>{const t=Bt/2,o=Math.min(window.innerHeight/2,t+Z),l=Math.max(o,window.innerHeight-t-Z);return{min:o/Math.max(1,window.innerHeight),max:l/Math.max(1,window.innerHeight)}},lt=t=>{const{min:o,max:l}=$t();return Math.min(l,Math.max(o,t))},z=()=>{const t=lt(F);n.style.setProperty("--wotty-toggle-top",`${t*100}%`)},ut=(t,o=!1)=>{F=lt(t),z(),o&&d.storage.local.set({[O]:F}).catch(()=>{})};M(),V(),d.storage.local.get(W).then(t=>{const o=t[W];typeof o=="number"&&Number.isFinite(o)&&(v=o),M()}).catch(()=>{}),d.storage.local.get(O).then(t=>{const o=t[O];typeof o=="number"&&Number.isFinite(o)&&(F=o),z()}).catch(()=>z()).finally(()=>{window.requestAnimationFrame(()=>{n.dataset.toggleReady="true"})});const b=()=>{window.clearTimeout(_),C&&(_=window.setTimeout(()=>j(!1,document.activeElement===n),kt))},j=(t,o=!0)=>{C=t,window.clearTimeout(_),n.dataset.open=String(t),s.setAttribute("aria-expanded",String(t)),s.setAttribute("aria-label",t?"\u6536\u8D77\u4E66\u7B7E\u4FA7\u680F\uFF1B\u53EF\u4E0A\u4E0B\u62D6\u52A8\u8C03\u6574\u4F4D\u7F6E":"\u5C55\u5F00\u4E66\u7B7E\u4FA7\u680F\uFF1B\u53EF\u4E0A\u4E0B\u62D6\u52A8\u8C03\u6574\u4F4D\u7F6E"),s.title=t?"\u6536\u8D77\u4E66\u7B7E\u4FA7\u680F\uFF1B\u53EF\u4E0A\u4E0B\u62D6\u52A8\u8C03\u6574\u4F4D\u7F6E":"\u5C55\u5F00\u4E66\u7B7E\u4FA7\u680F\uFF1B\u53EF\u4E0A\u4E0B\u62D6\u52A8\u8C03\u6574\u4F4D\u7F6E",u.setAttribute("aria-hidden",String(!t)),h.tabIndex=t?0:-1,i.setAttribute("aria-hidden",String(!t)),i.tabIndex=t?0:-1,t?b():o&&s.focus({preventScroll:!0})},ct=()=>{j(!C)},pt=t=>{typeof t=="object"&&t!==null&&"type"in t&&t.type===Ft&&ct()},mt=t=>{if(!(t.source!==h.contentWindow||t.origin!==Ht)&&!(typeof t.data!="object"||t.data===null||!("type"in t.data))){if(t.data.type===Lt){const o=t.data;if(!Number.isSafeInteger(o.id)||!Array.isArray(o.args))return;d.runtime.sendMessage(o).then(l=>{var c;return(c=h.contentWindow)==null?void 0:c.postMessage({type:X,id:o.id,value:l},"*")},l=>{var c;return(c=h.contentWindow)==null?void 0:c.postMessage({type:X,id:o.id,error:l instanceof Error?l.message:"\u6269\u5C55\u8BF7\u6C42\u5931\u8D25"},"*")});return}if(t.data.type===It){H=!0,window.clearTimeout(D),u.dataset.frameReady="true",delete u.dataset.frameError;return}t.data.type===Tt&&b()}},ht=()=>{H=!1,delete u.dataset.frameReady,delete u.dataset.frameError,window.clearTimeout(D),D=window.setTimeout(()=>{H||(u.dataset.frameError="true")},8e3),h.src=`${rt}?load=${++Ut}`};S.addEventListener("click",t=>{t.target.closest(".frame-placeholder-retry")&&ht()});const ft=t=>{t.composedPath().includes(n)&&b()},gt=t=>{!C||t.button!==0||(t.preventDefault(),B=t.pointerId,i.setPointerCapture(t.pointerId),n.dataset.resizing="true",b())},bt=t=>{B===t.pointerId&&(q(window.innerWidth-t.clientX),b())},N=t=>{B===t.pointerId&&(i.hasPointerCapture(t.pointerId)&&i.releasePointerCapture(t.pointerId),B=void 0,delete n.dataset.resizing,dt())},Et=t=>{const{min:o,max:l}=$();let c;t.key==="ArrowLeft"&&(c=v+20),t.key==="ArrowRight"&&(c=v-20),t.key==="Home"&&(c=o),t.key==="End"&&(c=l),c!==void 0&&(t.preventDefault(),q(c,!0),b())},wt=()=>q(J,!0),vt=t=>{t.button===0&&(t.preventDefault(),R=t.pointerId,it=t.clientY,T=!1,s.setPointerCapture(t.pointerId),b())},yt=t=>{R===t.pointerId&&(!T&&Math.abs(t.clientY-it)<Pt||(T=!0,n.dataset.positioning="true",ut(t.clientY/Math.max(1,window.innerHeight)),b()))},G=t=>{R===t.pointerId&&(s.hasPointerCapture(t.pointerId)&&s.releasePointerCapture(t.pointerId),R=void 0,T&&(ut(F,!0),P=!0,window.setTimeout(()=>{P=!1},0)),T=!1,delete n.dataset.positioning)},At=t=>{if(P){t.preventDefault(),t.stopPropagation(),P=!1;return}ct()},xt=()=>{M(),z(),V()},f=typeof ResizeObserver>"u"?void 0:new ResizeObserver(st);f==null||f.observe(document.documentElement),document.body&&(f==null||f.observe(document.body));const y=typeof MutationObserver>"u"?void 0:new MutationObserver(st);document.body&&(y==null||y.observe(document.body,{childList:!0,subtree:!0}));const St=["pointerdown","pointermove","keydown","wheel","touchstart","input","change","scroll"];St.forEach(t=>window.addEventListener(t,ft,{capture:!0,passive:!0})),s.addEventListener("pointerdown",vt),s.addEventListener("pointermove",yt),s.addEventListener("pointerup",G),s.addEventListener("pointercancel",G),s.addEventListener("click",At),i.addEventListener("pointerdown",gt),i.addEventListener("pointermove",bt),i.addEventListener("pointerup",N),i.addEventListener("pointercancel",N),i.addEventListener("keydown",Et),i.addEventListener("dblclick",wt),d.runtime.onMessage.addListener(pt),window.addEventListener("message",mt),ht(),a&&j(!0),window.addEventListener("resize",xt),r.onInvalidated(()=>{window.clearTimeout(_),window.clearTimeout(D),St.forEach(t=>window.removeEventListener(t,ft,!0)),s.removeEventListener("pointerdown",vt),s.removeEventListener("pointermove",yt),s.removeEventListener("pointerup",G),s.removeEventListener("pointercancel",G),s.removeEventListener("click",At),i.removeEventListener("pointerdown",gt),i.removeEventListener("pointermove",bt),i.removeEventListener("pointerup",N),i.removeEventListener("pointercancel",N),i.removeEventListener("keydown",Et),i.removeEventListener("dblclick",wt),window.removeEventListener("message",mt),window.removeEventListener("resize",xt),f==null||f.disconnect(),y==null||y.disconnect(),I!==void 0&&window.cancelAnimationFrame(I),d.runtime.onMessage.removeListener(pt),n.remove()})}};function L(r,...e){}const Nt={debug:(...r)=>L(console.debug,...r),log:(...r)=>L(console.log,...r),warn:(...r)=>L(console.warn,...r),error:(...r)=>L(console.error,...r)};var tt=(E=class extends Event{constructor(e,a){super(E.EVENT_NAME,{}),this.newUrl=e,this.oldUrl=a}},A(E,"EVENT_NAME",Y("wxt:locationchange")),E);function Y(r){var e;return`${(e=d==null?void 0:d.runtime)==null?void 0:e.id}:floating-sidebar:${r}`}const Gt=typeof((ot=globalThis.navigation)==null?void 0:ot.addEventListener)=="function";function Wt(r){let e,a=!1;return{run(){a||(a=!0,e=new URL(location.href),Gt?globalThis.navigation.addEventListener("navigate",n=>{const p=new URL(n.destination.url);p.href!==e.href&&(window.dispatchEvent(new tt(p,e)),e=p)},{signal:r.signal}):r.setInterval(()=>{const n=new URL(location.href);n.href!==e.href&&(window.dispatchEvent(new tt(n,e)),e=n)},1e3))}}}var Ot=(m=class{constructor(e,a){A(this,"id");A(this,"abortController");A(this,"locationWatcher",Wt(this));this.contentScriptName=e,this.options=a,this.id=Math.random().toString(36).slice(2),this.abortController=new AbortController,this.stopOldScripts(),this.listenForNewerScripts()}get signal(){return this.abortController.signal}abort(e){return this.abortController.abort(e)}get isInvalid(){var e;return((e=d.runtime)==null?void 0:e.id)==null&&this.notifyInvalidated(),this.signal.aborted}get isValid(){return!this.isInvalid}onInvalidated(e){return this.signal.addEventListener("abort",e),()=>this.signal.removeEventListener("abort",e)}block(){return new Promise(()=>{})}setInterval(e,a){const n=setInterval(()=>{this.isValid&&e()},a);return this.onInvalidated(()=>clearInterval(n)),n}setTimeout(e,a){const n=setTimeout(()=>{this.isValid&&e()},a);return this.onInvalidated(()=>clearTimeout(n)),n}requestAnimationFrame(e){const a=requestAnimationFrame((...n)=>{this.isValid&&e(...n)});return this.onInvalidated(()=>cancelAnimationFrame(a)),a}requestIdleCallback(e,a){const n=requestIdleCallback((...p)=>{this.signal.aborted||e(...p)},a);return this.onInvalidated(()=>cancelIdleCallback(n)),n}addEventListener(e,a,n,p){var g;a==="wxt:locationchange"&&this.isValid&&this.locationWatcher.run(),(g=e.addEventListener)==null||g.call(e,a.startsWith("wxt:")?Y(a):a,n,{...p,signal:this.signal})}notifyInvalidated(){this.abort("Content script context invalidated"),Nt.debug(`Content script "${this.contentScriptName}" context invalidated`)}stopOldScripts(){var e;document.dispatchEvent(new CustomEvent(m.SCRIPT_STARTED_MESSAGE_TYPE,{detail:{contentScriptName:this.contentScriptName,messageId:this.id}})),(e=this.options)!=null&&e.noScriptStartedPostMessage||window.postMessage({type:m.SCRIPT_STARTED_MESSAGE_TYPE,contentScriptName:this.contentScriptName,messageId:this.id},"*")}verifyScriptStartedEvent(e){var p,g;const a=((p=e.detail)==null?void 0:p.contentScriptName)===this.contentScriptName,n=((g=e.detail)==null?void 0:g.messageId)===this.id;return a&&!n}listenForNewerScripts(){const e=a=>{!(a instanceof CustomEvent)||!this.verifyScriptStartedEvent(a)||this.notifyInvalidated()};document.addEventListener(m.SCRIPT_STARTED_MESSAGE_TYPE,e),this.onInvalidated(()=>document.removeEventListener(m.SCRIPT_STARTED_MESSAGE_TYPE,e))}},A(m,"SCRIPT_STARTED_MESSAGE_TYPE",Y("wxt:content-script-started")),m);function jt(){}function k(r,...e){}const Yt={debug:(...r)=>k(console.debug,...r),log:(...r)=>k(console.log,...r),warn:(...r)=>k(console.warn,...r),error:(...r)=>k(console.error,...r)};return(async()=>{try{const{main:r,...e}=zt;return await r(new Ot("floating-sidebar",e))}catch(r){throw Yt.error('The content script "floating-sidebar" crashed on startup!',r),r}})()})();

floatingSidebar;