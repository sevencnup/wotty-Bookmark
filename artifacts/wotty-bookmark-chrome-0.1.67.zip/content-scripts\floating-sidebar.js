var floatingSidebar=(function(){"use strict";var Ut=Object.defineProperty;var Ht=(w,d,A)=>d in w?Ut(w,d,{enumerable:!0,configurable:!0,writable:!0,value:A}):w[d]=A;var x=(w,d,A)=>Ht(w,typeof d!="symbol"?d+"":d,A);var tt,et,b,nt,p;const d=(et=(tt=globalThis.browser)==null?void 0:tt.runtime)!=null&&et.id?globalThis.browser:globalThis.chrome;function A(o){return o}const K="wotty-bookmark-floating-sidebar",X="0.1.67-open-2",At="wotty-bookmark:toggle-floating-sidebar",St="wotty-bookmark:sidebar-activity",Ft="wotty-bookmark:sidebar-ready",Tt=5e3,W="bookmark-vault.floating-sidebar-width.v1",Y="bookmark-vault.floating-sidebar-toggle-position.v1",J=390,It=280,Lt=44,Ct=.5,Dt=34,Q=8,kt=14,Bt=4,_t=`
:host {
  all: initial !important;
  position: fixed !important;
  inset: 0 !important;
  z-index: 2147483647 !important;
  display: block !important;
  width: 100vw !important;
  height: 100vh !important;
  margin: 0 !important;
  padding: 0 !important;
  border: 0 !important;
  pointer-events: none !important;
  overflow: clip !important;
  --wotty-sidebar-width: min(390px, calc(100vw - 44px));
  --wotty-toggle-top: 50%;
  --wotty-scrollbar-width: 0px;
}

*, *::before, *::after { box-sizing: border-box; }

.panel {
  position: absolute;
  top: 0;
  right: 0;
  width: var(--wotty-sidebar-width);
  height: 100vh;
  height: 100dvh;
  overflow: hidden;
  border-left: 1px solid #dbe4f0;
  background: #f8fafc;
  box-shadow: -14px 0 36px rgba(15, 23, 42, 0.2);
  pointer-events: none;
  transform: translate3d(calc(100% + 48px), 0, 0);
  transition: transform 210ms cubic-bezier(0.25, 1, 0.5, 1);
  will-change: transform;
}

:host([data-open='true']) .panel {
  transform: translate3d(0, 0, 0);
  transition-duration: 280ms;
  pointer-events: auto;
}

.panel iframe {
  display: block;
  width: 100%;
  height: 100%;
  border: 0;
  background: #f8fafc;
}

.frame-placeholder {
  position: absolute;
  inset: 0;
  z-index: 2;
  display: grid;
  align-content: center;
  justify-items: center;
  gap: 10px;
  background: #f8fafc;
  color: #475569;
  font: 13px/1.5 -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
}

.frame-placeholder-spinner {
  width: 22px;
  height: 22px;
  border: 2px solid #bfdbfe;
  border-top-color: #2563eb;
  border-radius: 50%;
  animation: wotty-sidebar-spin 700ms linear infinite;
}

.frame-placeholder-error {
  display: none;
  max-width: 260px;
  padding: 0 18px;
  text-align: center;
}

.frame-placeholder-retry {
  display: block;
  margin: 12px auto 0;
  padding: 7px 12px;
  border: 1px solid #bfdbfe;
  border-radius: 7px;
  background: #ffffff;
  color: #1d4ed8;
  cursor: pointer;
}

.panel[data-frame-error='true'] .frame-placeholder-spinner,
.panel[data-frame-error='true'] .frame-placeholder-message {
  display: none;
}

.panel[data-frame-error='true'] .frame-placeholder-error { display: block; }
.panel[data-frame-ready='true'] .frame-placeholder { display: none; }

@keyframes wotty-sidebar-spin { to { transform: rotate(360deg); } }

.resize-handle {
  position: absolute;
  top: 0;
  right: calc(var(--wotty-sidebar-width) - 4px);
  z-index: 1;
  width: 8px;
  height: 100vh;
  height: 100dvh;
  cursor: col-resize;
  opacity: 0;
  pointer-events: none;
  touch-action: none;
  transform: translate3d(calc(var(--wotty-sidebar-width) + 48px), 0, 0);
  transition: transform 210ms cubic-bezier(0.25, 1, 0.5, 1), opacity 160ms ease;
}

.resize-handle::after {
  position: absolute;
  top: 50%;
  left: 2px;
  width: 3px;
  height: 44px;
  border-radius: 999px;
  background: #cbd5e1;
  box-shadow: 0 0 0 1px rgba(255, 255, 255, 0.9), 0 1px 5px rgba(15, 23, 42, 0.16);
  content: '';
  transform: translateY(-50%);
  transition: background 160ms ease, box-shadow 160ms ease, transform 160ms ease;
}

:host([data-open='true']) .resize-handle {
  transform: translate3d(0, 0, 0);
  transition-duration: 280ms, 160ms;
  opacity: 0.6;
  pointer-events: auto;
}

.resize-handle:hover,
:host([data-resizing='true']) .resize-handle {
  opacity: 1;
}

.resize-handle:hover::after,
:host([data-resizing='true']) .resize-handle::after {
  background: #2563eb;
  box-shadow: 0 0 0 1px #ffffff, 0 2px 8px rgba(37, 99, 235, 0.38);
  transform: translateY(-50%) scaleY(1.18);
}

.resize-handle:focus-visible::after {
  background: #2563eb;
  box-shadow: 0 0 0 3px #bfdbfe;
}

.edge-toggle {
  position: absolute;
  top: var(--wotty-toggle-top);
  right: calc(5px + var(--wotty-scrollbar-width));
  display: grid;
  width: 34px;
  height: 34px;
  place-items: center;
  padding: 0;
  border: 1px solid #ffffff;
  border-radius: 50%;
  background: rgba(255, 255, 255, 0.98);
  box-shadow: 0 0 0 1px rgba(37, 99, 235, 0.42), 0 4px 12px rgba(15, 23, 42, 0.26);
  cursor: pointer;
  opacity: 0;
  pointer-events: auto;
  touch-action: none;
  user-select: none;
  visibility: hidden;
  transform: translateY(-50%);
  transition: right 220ms cubic-bezier(0.16, 1, 0.3, 1), transform 160ms ease, background 160ms ease, box-shadow 160ms ease, opacity 120ms ease;
}

:host([data-toggle-ready='true']) .edge-toggle {
  opacity: 1;
  visibility: visible;
}

.edge-toggle:hover {
  background: #eff6ff;
  box-shadow: 0 0 0 2px rgba(37, 99, 235, 0.2), 0 6px 16px rgba(15, 23, 42, 0.3);
  transform: translateY(-50%) scale(1.08);
}

.edge-toggle:focus-visible {
  outline: 3px solid #93c5fd;
  outline-offset: -4px;
}

:host([data-open='true']) .edge-toggle {
  right: calc(5px + var(--wotty-scrollbar-width));
  background: #eff6ff;
  box-shadow: 0 0 0 1px rgba(37, 99, 235, 0.46), 0 4px 12px rgba(15, 23, 42, 0.24);
}

:host([data-positioning='true']) .edge-toggle {
  cursor: grabbing;
  transform: translateY(-50%);
  transition: none;
}

.edge-toggle img {
  display: block;
  width: 25px;
  height: 25px;
  object-fit: contain;
  pointer-events: none;
}

@media (prefers-reduced-motion: reduce) {
  .panel, .resize-handle, .resize-handle::after, .edge-toggle { transition: none; }
}
`,Rt={matches:["http://*/*","https://*/*"],runAt:"document_idle",main(o){const e=document.getElementById(K);if((e==null?void 0:e.dataset.build)===X)return;const r=(e==null?void 0:e.dataset.open)==="true"||document.documentElement.getAttribute("data-wotty-sidebar-restore-open")==="true";document.documentElement.removeAttribute("data-wotty-sidebar-restore-open"),e==null||e.remove();const n=document.createElement("wotty-bookmark-floating-sidebar");n.id=K,n.dataset.build=X,n.style.cssText="all:initial!important;position:fixed!important;inset:0!important;z-index:2147483647!important;display:block!important;width:100vw!important;height:100vh!important;margin:0!important;padding:0!important;border:0!important;pointer-events:none!important;";const u=n.attachShadow({mode:"closed"}),h=document.createElement("style");h.textContent=_t;const l=document.createElement("aside");l.className="panel",l.id="wotty-bookmark-floating-panel",l.setAttribute("role","complementary"),l.setAttribute("aria-label","\u4E66\u7B7E\u4FA7\u680F"),l.setAttribute("aria-hidden","true");const E=document.createElement("iframe");E.title="\u4E66\u7B7E\u4FA7\u680F",E.setAttribute("loading","eager"),E.tabIndex=-1,l.append(E);const S=document.createElement("div");S.className="frame-placeholder",S.setAttribute("role","status"),S.innerHTML='<span class="frame-placeholder-spinner" aria-hidden="true"></span><span class="frame-placeholder-message">\u6B63\u5728\u52A0\u8F7D\u4E66\u7B7E\u4FA7\u680F\u2026</span><span class="frame-placeholder-error">\u4FA7\u680F\u6682\u65F6\u65E0\u6CD5\u52A0\u8F7D\u3002<button class="frame-placeholder-retry" type="button">\u91CD\u65B0\u52A0\u8F7D</button></span>',l.append(S);const i=document.createElement("div");i.className="resize-handle",i.setAttribute("aria-hidden","true"),i.setAttribute("aria-label","\u8C03\u6574\u4E66\u7B7E\u4FA7\u680F\u5BBD\u5EA6"),i.setAttribute("aria-orientation","vertical"),i.setAttribute("role","separator"),i.tabIndex=-1,i.title="\u62D6\u52A8\u8C03\u6574\u4FA7\u680F\u5BBD\u5EA6\uFF1B\u53CC\u51FB\u6062\u590D\u9ED8\u8BA4\u5BBD\u5EA6";const s=document.createElement("button");s.className="edge-toggle",s.type="button",s.setAttribute("aria-controls",l.id),s.setAttribute("aria-expanded","false"),s.setAttribute("aria-label","\u5C55\u5F00\u4E66\u7B7E\u4FA7\u680F\uFF1B\u53EF\u4E0A\u4E0B\u62D6\u52A8\u8C03\u6574\u4F4D\u7F6E"),s.title="\u5C55\u5F00\u4E66\u7B7E\u4FA7\u680F\uFF1B\u53EF\u4E0A\u4E0B\u62D6\u52A8\u8C03\u6574\u4F4D\u7F6E";const U=document.createElement("img");U.alt="",U.src=d.runtime.getURL("/logo.webp"),s.append(U),u.append(h,l,i,s),document.documentElement.append(n);let D=!1,H=!1,k,Wt=0;const Yt=d.runtime.getURL("/sidebar-frame.html");let B,v=J,_,F=Ct,R,ot=0,T=!1,P=!1,I;const $=()=>{const t=Math.max(1,window.innerWidth-Lt);return{min:Math.min(It,t),max:t}},it=t=>{const{min:a,max:c}=$();return Math.min(c,Math.max(a,Math.round(t)))},M=()=>{const t=it(v);n.style.setProperty("--wotty-sidebar-width",`${t}px`);const{min:a,max:c}=$();i.setAttribute("aria-valuemin",String(a)),i.setAttribute("aria-valuemax",String(c)),i.setAttribute("aria-valuenow",String(t))},V=()=>{const t=document.documentElement,a=Math.max(0,window.innerWidth-t.clientWidth),c=t.scrollHeight>t.clientHeight,g=a||(c?kt:0);n.style.setProperty("--wotty-scrollbar-width",`${g}px`)},rt=()=>{I===void 0&&(I=window.requestAnimationFrame(()=>{I=void 0,V()}))},at=()=>{d.storage.local.set({[W]:v}).catch(()=>{})},q=(t,a=!1)=>{v=it(t),M(),a&&at()},Ot=()=>{const t=Dt/2,a=Math.min(window.innerHeight/2,t+Q),c=Math.max(a,window.innerHeight-t-Q);return{min:a/Math.max(1,window.innerHeight),max:c/Math.max(1,window.innerHeight)}},st=t=>{const{min:a,max:c}=Ot();return Math.min(c,Math.max(a,t))},z=()=>{const t=st(F);n.style.setProperty("--wotty-toggle-top",`${t*100}%`)},dt=(t,a=!1)=>{F=st(t),z(),a&&d.storage.local.set({[Y]:F}).catch(()=>{})};M(),V(),d.storage.local.get(W).then(t=>{const a=t[W];typeof a=="number"&&Number.isFinite(a)&&(v=a),M()}).catch(()=>{}),d.storage.local.get(Y).then(t=>{const a=t[Y];typeof a=="number"&&Number.isFinite(a)&&(F=a),z()}).catch(()=>z()).finally(()=>{window.requestAnimationFrame(()=>{n.dataset.toggleReady="true"})});const f=()=>{window.clearTimeout(B),D&&(B=window.setTimeout(()=>j(!1,document.activeElement===n),Tt))},j=(t,a=!0)=>{D=t,window.clearTimeout(B),n.dataset.open=String(t),s.setAttribute("aria-expanded",String(t)),s.setAttribute("aria-label",t?"\u6536\u8D77\u4E66\u7B7E\u4FA7\u680F\uFF1B\u53EF\u4E0A\u4E0B\u62D6\u52A8\u8C03\u6574\u4F4D\u7F6E":"\u5C55\u5F00\u4E66\u7B7E\u4FA7\u680F\uFF1B\u53EF\u4E0A\u4E0B\u62D6\u52A8\u8C03\u6574\u4F4D\u7F6E"),s.title=t?"\u6536\u8D77\u4E66\u7B7E\u4FA7\u680F\uFF1B\u53EF\u4E0A\u4E0B\u62D6\u52A8\u8C03\u6574\u4F4D\u7F6E":"\u5C55\u5F00\u4E66\u7B7E\u4FA7\u680F\uFF1B\u53EF\u4E0A\u4E0B\u62D6\u52A8\u8C03\u6574\u4F4D\u7F6E",l.setAttribute("aria-hidden",String(!t)),E.tabIndex=t?0:-1,i.setAttribute("aria-hidden",String(!t)),i.tabIndex=t?0:-1,t?f():a&&s.focus({preventScroll:!0})},lt=()=>{j(!D)},ut=t=>{typeof t=="object"&&t!==null&&"type"in t&&t.type===At&&lt()},ct=t=>{if(t.source===E.contentWindow&&!(typeof t.data!="object"||t.data===null||!("type"in t.data))){if(t.data.type===Ft){H=!0,window.clearTimeout(k),l.dataset.frameReady="true",delete l.dataset.frameError;return}t.data.type===St&&f()}},pt=()=>{H=!1,delete l.dataset.frameReady,delete l.dataset.frameError,window.clearTimeout(k),k=window.setTimeout(()=>{H||(l.dataset.frameError="true")},8e3),E.src=`${Yt}?load=${++Wt}`};S.addEventListener("click",t=>{t.target.closest(".frame-placeholder-retry")&&pt()});const mt=t=>{t.composedPath().includes(n)&&f()},ht=t=>{!D||t.button!==0||(t.preventDefault(),_=t.pointerId,i.setPointerCapture(t.pointerId),n.dataset.resizing="true",f())},ft=t=>{_===t.pointerId&&(q(window.innerWidth-t.clientX),f())},N=t=>{_===t.pointerId&&(i.hasPointerCapture(t.pointerId)&&i.releasePointerCapture(t.pointerId),_=void 0,delete n.dataset.resizing,at())},gt=t=>{const{min:a,max:c}=$();let g;t.key==="ArrowLeft"&&(g=v+20),t.key==="ArrowRight"&&(g=v-20),t.key==="Home"&&(g=a),t.key==="End"&&(g=c),g!==void 0&&(t.preventDefault(),q(g,!0),f())},bt=()=>q(J,!0),Et=t=>{t.button===0&&(t.preventDefault(),R=t.pointerId,ot=t.clientY,T=!1,s.setPointerCapture(t.pointerId),f())},wt=t=>{R===t.pointerId&&(!T&&Math.abs(t.clientY-ot)<Bt||(T=!0,n.dataset.positioning="true",dt(t.clientY/Math.max(1,window.innerHeight)),f()))},G=t=>{R===t.pointerId&&(s.hasPointerCapture(t.pointerId)&&s.releasePointerCapture(t.pointerId),R=void 0,T&&(dt(F,!0),P=!0,window.setTimeout(()=>{P=!1},0)),T=!1,delete n.dataset.positioning)},vt=t=>{if(P){t.preventDefault(),t.stopPropagation(),P=!1;return}lt()},yt=()=>{M(),z(),V()},m=typeof ResizeObserver>"u"?void 0:new ResizeObserver(rt);m==null||m.observe(document.documentElement),document.body&&(m==null||m.observe(document.body));const y=typeof MutationObserver>"u"?void 0:new MutationObserver(rt);document.body&&(y==null||y.observe(document.body,{childList:!0,subtree:!0}));const xt=["pointerdown","pointermove","keydown","wheel","touchstart","input","change","scroll"];xt.forEach(t=>window.addEventListener(t,mt,{capture:!0,passive:!0})),s.addEventListener("pointerdown",Et),s.addEventListener("pointermove",wt),s.addEventListener("pointerup",G),s.addEventListener("pointercancel",G),s.addEventListener("click",vt),i.addEventListener("pointerdown",ht),i.addEventListener("pointermove",ft),i.addEventListener("pointerup",N),i.addEventListener("pointercancel",N),i.addEventListener("keydown",gt),i.addEventListener("dblclick",bt),d.runtime.onMessage.addListener(ut),window.addEventListener("message",ct),pt(),r&&j(!0),window.addEventListener("resize",yt),o.onInvalidated(()=>{window.clearTimeout(B),window.clearTimeout(k),xt.forEach(t=>window.removeEventListener(t,mt,!0)),s.removeEventListener("pointerdown",Et),s.removeEventListener("pointermove",wt),s.removeEventListener("pointerup",G),s.removeEventListener("pointercancel",G),s.removeEventListener("click",vt),i.removeEventListener("pointerdown",ht),i.removeEventListener("pointermove",ft),i.removeEventListener("pointerup",N),i.removeEventListener("pointercancel",N),i.removeEventListener("keydown",gt),i.removeEventListener("dblclick",bt),window.removeEventListener("message",ct),window.removeEventListener("resize",yt),m==null||m.disconnect(),y==null||y.disconnect(),I!==void 0&&window.cancelAnimationFrame(I),d.runtime.onMessage.removeListener(ut),n.remove()})}};function L(o,...e){}const Pt={debug:(...o)=>L(console.debug,...o),log:(...o)=>L(console.log,...o),warn:(...o)=>L(console.warn,...o),error:(...o)=>L(console.error,...o)};var Z=(b=class extends Event{constructor(e,r){super(b.EVENT_NAME,{}),this.newUrl=e,this.oldUrl=r}},x(b,"EVENT_NAME",O("wxt:locationchange")),b);function O(o){var e;return`${(e=d==null?void 0:d.runtime)==null?void 0:e.id}:floating-sidebar:${o}`}const Mt=typeof((nt=globalThis.navigation)==null?void 0:nt.addEventListener)=="function";function zt(o){let e,r=!1;return{run(){r||(r=!0,e=new URL(location.href),Mt?globalThis.navigation.addEventListener("navigate",n=>{const u=new URL(n.destination.url);u.href!==e.href&&(window.dispatchEvent(new Z(u,e)),e=u)},{signal:o.signal}):o.setInterval(()=>{const n=new URL(location.href);n.href!==e.href&&(window.dispatchEvent(new Z(n,e)),e=n)},1e3))}}}var Nt=(p=class{constructor(e,r){x(this,"id");x(this,"abortController");x(this,"locationWatcher",zt(this));this.contentScriptName=e,this.options=r,this.id=Math.random().toString(36).slice(2),this.abortController=new AbortController,this.stopOldScripts(),this.listenForNewerScripts()}get signal(){return this.abortController.signal}abort(e){return this.abortController.abort(e)}get isInvalid(){var e;return((e=d.runtime)==null?void 0:e.id)==null&&this.notifyInvalidated(),this.signal.aborted}get isValid(){return!this.isInvalid}onInvalidated(e){return this.signal.addEventListener("abort",e),()=>this.signal.removeEventListener("abort",e)}block(){return new Promise(()=>{})}setInterval(e,r){const n=setInterval(()=>{this.isValid&&e()},r);return this.onInvalidated(()=>clearInterval(n)),n}setTimeout(e,r){const n=setTimeout(()=>{this.isValid&&e()},r);return this.onInvalidated(()=>clearTimeout(n)),n}requestAnimationFrame(e){const r=requestAnimationFrame((...n)=>{this.isValid&&e(...n)});return this.onInvalidated(()=>cancelAnimationFrame(r)),r}requestIdleCallback(e,r){const n=requestIdleCallback((...u)=>{this.signal.aborted||e(...u)},r);return this.onInvalidated(()=>cancelIdleCallback(n)),n}addEventListener(e,r,n,u){var h;r==="wxt:locationchange"&&this.isValid&&this.locationWatcher.run(),(h=e.addEventListener)==null||h.call(e,r.startsWith("wxt:")?O(r):r,n,{...u,signal:this.signal})}notifyInvalidated(){this.abort("Content script context invalidated"),Pt.debug(`Content script "${this.contentScriptName}" context invalidated`)}stopOldScripts(){var e;document.dispatchEvent(new CustomEvent(p.SCRIPT_STARTED_MESSAGE_TYPE,{detail:{contentScriptName:this.contentScriptName,messageId:this.id}})),(e=this.options)!=null&&e.noScriptStartedPostMessage||window.postMessage({type:p.SCRIPT_STARTED_MESSAGE_TYPE,contentScriptName:this.contentScriptName,messageId:this.id},"*")}verifyScriptStartedEvent(e){var u,h;const r=((u=e.detail)==null?void 0:u.contentScriptName)===this.contentScriptName,n=((h=e.detail)==null?void 0:h.messageId)===this.id;return r&&!n}listenForNewerScripts(){const e=r=>{!(r instanceof CustomEvent)||!this.verifyScriptStartedEvent(r)||this.notifyInvalidated()};document.addEventListener(p.SCRIPT_STARTED_MESSAGE_TYPE,e),this.onInvalidated(()=>document.removeEventListener(p.SCRIPT_STARTED_MESSAGE_TYPE,e))}},x(p,"SCRIPT_STARTED_MESSAGE_TYPE",O("wxt:content-script-started")),p);function $t(){}function C(o,...e){}const Gt={debug:(...o)=>C(console.debug,...o),log:(...o)=>C(console.log,...o),warn:(...o)=>C(console.warn,...o),error:(...o)=>C(console.error,...o)};return(async()=>{try{const{main:o,...e}=Rt;return await o(new Nt("floating-sidebar",e))}catch(o){throw Gt.error('The content script "floating-sidebar" crashed on startup!',o),o}})()})();

floatingSidebar;