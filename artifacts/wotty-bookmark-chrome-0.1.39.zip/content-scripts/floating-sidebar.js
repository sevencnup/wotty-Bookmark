var floatingSidebar=(function(){"use strict";var lt=Object.defineProperty;var ct=(h,s,v)=>s in h?lt(h,s,{enumerable:!0,configurable:!0,writable:!0,value:v}):h[s]=v;var f=(h,s,v)=>ct(h,typeof s!="symbol"?s+"":s,v);var B,M,p,N,u;const s=(M=(B=globalThis.browser)==null?void 0:B.runtime)!=null&&M.id?globalThis.browser:globalThis.chrome;function v(i){return i}const R="wotty-bookmark-floating-sidebar",J="wotty-bookmark:toggle-floating-sidebar",Q="wotty-bookmark:sidebar-activity",Z=5e3,L="bookmark-vault.floating-sidebar-width.v1",_=390,tt=280,et=44,it=`
:host {
  all: initial !important;
  position: fixed !important;
  inset: 0 !important;
  z-index: 2147483647 !important;
  display: block !important;
  width: 100vw !important;
  height: 100vh !important;
  margin: 0 !important;
  padding: 0 !important;
  border: 0 !important;
  pointer-events: none !important;
  --wotty-sidebar-width: min(390px, calc(100vw - 44px));
}

*, *::before, *::after { box-sizing: border-box; }

.panel {
  position: absolute;
  top: 0;
  right: 0;
  width: var(--wotty-sidebar-width);
  height: 100vh;
  height: 100dvh;
  overflow: hidden;
  border-left: 1px solid #dbe4f0;
  background: #f8fafc;
  box-shadow: -14px 0 36px rgba(15, 23, 42, 0.2);
  opacity: 0;
  pointer-events: none;
  transform: translateX(100%);
  visibility: hidden;
  transition: transform 220ms cubic-bezier(0.16, 1, 0.3, 1), opacity 160ms ease, visibility 0s linear 220ms;
}

:host([data-open='true']) .panel {
  opacity: 1;
  pointer-events: auto;
  transform: translateX(0);
  visibility: visible;
  transition: transform 220ms cubic-bezier(0.16, 1, 0.3, 1), opacity 160ms ease, visibility 0s;
}

.panel iframe {
  display: block;
  width: 100%;
  height: 100%;
  border: 0;
  background: #f8fafc;
}

.resize-handle {
  position: absolute;
  top: 0;
  right: calc(var(--wotty-sidebar-width) - 4px);
  z-index: 1;
  width: 8px;
  height: 100vh;
  height: 100dvh;
  cursor: col-resize;
  opacity: 0;
  pointer-events: none;
  touch-action: none;
  transition: opacity 160ms ease;
}

.resize-handle::after {
  position: absolute;
  top: 50%;
  left: 2px;
  width: 3px;
  height: 44px;
  border-radius: 999px;
  background: #cbd5e1;
  box-shadow: 0 0 0 1px rgba(255, 255, 255, 0.9), 0 1px 5px rgba(15, 23, 42, 0.16);
  content: '';
  transform: translateY(-50%);
  transition: background 160ms ease, box-shadow 160ms ease, transform 160ms ease;
}

:host([data-open='true']) .resize-handle {
  opacity: 0.6;
  pointer-events: auto;
}

.resize-handle:hover,
:host([data-resizing='true']) .resize-handle {
  opacity: 1;
}

.resize-handle:hover::after,
:host([data-resizing='true']) .resize-handle::after {
  background: #2563eb;
  box-shadow: 0 0 0 1px #ffffff, 0 2px 8px rgba(37, 99, 235, 0.38);
  transform: translateY(-50%) scaleY(1.18);
}

.resize-handle:focus-visible::after {
  background: #2563eb;
  box-shadow: 0 0 0 3px #bfdbfe;
}

.edge-toggle {
  position: absolute;
  top: 50%;
  right: 5px;
  display: grid;
  width: 34px;
  height: 34px;
  place-items: center;
  padding: 0;
  border: 1px solid #ffffff;
  border-radius: 50%;
  background: rgba(255, 255, 255, 0.98);
  box-shadow: 0 0 0 1px rgba(37, 99, 235, 0.42), 0 4px 12px rgba(15, 23, 42, 0.26);
  backdrop-filter: blur(10px);
  cursor: pointer;
  pointer-events: auto;
  transform: translateY(-50%);
  transition: right 220ms cubic-bezier(0.16, 1, 0.3, 1), transform 160ms ease, background 160ms ease, box-shadow 160ms ease;
}

.edge-toggle:hover {
  background: #eff6ff;
  box-shadow: 0 0 0 2px rgba(37, 99, 235, 0.2), 0 6px 16px rgba(15, 23, 42, 0.3);
  transform: translateY(-50%) scale(1.08);
}

.edge-toggle:focus-visible {
  outline: 3px solid #93c5fd;
  outline-offset: -4px;
}

:host([data-open='true']) .edge-toggle {
  right: 5px;
  background: #eff6ff;
  box-shadow: 0 0 0 1px rgba(37, 99, 235, 0.46), 0 4px 12px rgba(15, 23, 42, 0.24);
}

.edge-toggle img {
  display: block;
  width: 25px;
  height: 25px;
  object-fit: contain;
  pointer-events: none;
}

@media (prefers-reduced-motion: reduce) {
  .panel, .resize-handle, .resize-handle::after, .edge-toggle { transition: none; }
}
`,nt={matches:["http://*/*","https://*/*"],runAt:"document_idle",main(i){if(document.getElementById(R))return;const t=document.createElement("wotty-bookmark-floating-sidebar");t.id=R,t.style.cssText="all:initial!important;position:fixed!important;inset:0!important;z-index:2147483647!important;display:block!important;width:100vw!important;height:100vh!important;margin:0!important;padding:0!important;border:0!important;pointer-events:none!important;";const r=t.attachShadow({mode:"closed"}),o=document.createElement("style");o.textContent=it;const a=document.createElement("aside");a.className="panel",a.id="wotty-bookmark-floating-panel",a.setAttribute("role","complementary"),a.setAttribute("aria-label","\u4E66\u7B7E\u4FA7\u680F"),a.setAttribute("aria-hidden","true");const d=document.createElement("iframe");d.title="\u4E66\u7B7E\u4FA7\u680F",d.setAttribute("loading","eager"),d.inert=!0,d.src=s.runtime.getURL("/sidebar-frame.html"),a.append(d);const n=document.createElement("div");n.className="resize-handle",n.setAttribute("aria-hidden","true"),n.setAttribute("aria-label","\u8C03\u6574\u4E66\u7B7E\u4FA7\u680F\u5BBD\u5EA6"),n.setAttribute("aria-orientation","vertical"),n.setAttribute("role","separator"),n.tabIndex=-1,n.title="\u62D6\u52A8\u8C03\u6574\u4FA7\u680F\u5BBD\u5EA6\uFF1B\u53CC\u51FB\u6062\u590D\u9ED8\u8BA4\u5BBD\u5EA6";const l=document.createElement("button");l.className="edge-toggle",l.type="button",l.setAttribute("aria-controls",a.id),l.setAttribute("aria-expanded","false"),l.setAttribute("aria-label","\u5C55\u5F00\u4E66\u7B7E\u4FA7\u680F"),l.title="\u5C55\u5F00\u4E66\u7B7E\u4FA7\u680F";const C=document.createElement("img");C.alt="",C.src=s.runtime.getURL("/logo.webp"),l.append(C),r.append(o,a,n,l),document.documentElement.append(t);let S=!1,A,m=_,y;const F=()=>{const e=Math.max(1,window.innerWidth-et);return{min:Math.min(tt,e),max:e}},P=e=>{const{min:c,max:E}=F();return Math.min(E,Math.max(c,Math.round(e)))},I=()=>{const e=P(m);t.style.setProperty("--wotty-sidebar-width",`${e}px`);const{min:c,max:E}=F();n.setAttribute("aria-valuemin",String(c)),n.setAttribute("aria-valuemax",String(E)),n.setAttribute("aria-valuenow",String(e))},W=()=>{s.storage.local.set({[L]:m}).catch(()=>{})},z=(e,c=!1)=>{m=P(e),I(),c&&W()};I(),s.storage.local.get(L).then(e=>{const c=e[L];typeof c=="number"&&Number.isFinite(c)&&(m=c),I()}).catch(()=>{});const b=()=>{window.clearTimeout(A),S&&(A=window.setTimeout(()=>U(!1,document.activeElement===t),Z))},U=(e,c=!0)=>{S=e,window.clearTimeout(A),t.dataset.open=String(e),l.setAttribute("aria-expanded",String(e)),l.setAttribute("aria-label",e?"\u6536\u8D77\u4E66\u7B7E\u4FA7\u680F":"\u5C55\u5F00\u4E66\u7B7E\u4FA7\u680F"),l.title=e?"\u6536\u8D77\u4E66\u7B7E\u4FA7\u680F":"\u5C55\u5F00\u4E66\u7B7E\u4FA7\u680F",a.setAttribute("aria-hidden",String(!e)),d.inert=!e,n.setAttribute("aria-hidden",String(!e)),n.tabIndex=e?0:-1,e?b():c&&l.focus({preventScroll:!0})},Y=()=>U(!S),G=e=>{typeof e=="object"&&e!==null&&"type"in e&&e.type===J&&Y()},O=e=>{e.source===d.contentWindow&&typeof e.data=="object"&&e.data!==null&&"type"in e.data&&e.data.type===Q&&b()},V=e=>{e.composedPath().includes(t)&&b()},$=e=>{!S||e.button!==0||(e.preventDefault(),y=e.pointerId,n.setPointerCapture(e.pointerId),t.dataset.resizing="true",b())},H=e=>{y===e.pointerId&&(z(window.innerWidth-e.clientX),b())},T=e=>{y===e.pointerId&&(n.hasPointerCapture(e.pointerId)&&n.releasePointerCapture(e.pointerId),y=void 0,delete t.dataset.resizing,W())},q=e=>{const{min:c,max:E}=F();let g;e.key==="ArrowLeft"&&(g=m+20),e.key==="ArrowRight"&&(g=m-20),e.key==="Home"&&(g=c),e.key==="End"&&(g=E),g!==void 0&&(e.preventDefault(),z(g,!0),b())},j=()=>z(_,!0),X=()=>I(),K=["pointerdown","pointermove","keydown","wheel","touchstart","input","change","scroll"];K.forEach(e=>window.addEventListener(e,V,{capture:!0,passive:!0})),l.addEventListener("click",Y),n.addEventListener("pointerdown",$),n.addEventListener("pointermove",H),n.addEventListener("pointerup",T),n.addEventListener("pointercancel",T),n.addEventListener("keydown",q),n.addEventListener("dblclick",j),s.runtime.onMessage.addListener(G),window.addEventListener("message",O),window.addEventListener("resize",X),i.onInvalidated(()=>{window.clearTimeout(A),K.forEach(e=>window.removeEventListener(e,V,!0)),n.removeEventListener("pointerdown",$),n.removeEventListener("pointermove",H),n.removeEventListener("pointerup",T),n.removeEventListener("pointercancel",T),n.removeEventListener("keydown",q),n.removeEventListener("dblclick",j),window.removeEventListener("message",O),window.removeEventListener("resize",X),s.runtime.onMessage.removeListener(G),t.remove()})}};function w(i,...t){}const rt={debug:(...i)=>w(console.debug,...i),log:(...i)=>w(console.log,...i),warn:(...i)=>w(console.warn,...i),error:(...i)=>w(console.error,...i)};var D=(p=class extends Event{constructor(t,r){super(p.EVENT_NAME,{}),this.newUrl=t,this.oldUrl=r}},f(p,"EVENT_NAME",k("wxt:locationchange")),p);function k(i){var t;return`${(t=s==null?void 0:s.runtime)==null?void 0:t.id}:floating-sidebar:${i}`}const ot=typeof((N=globalThis.navigation)==null?void 0:N.addEventListener)=="function";function at(i){let t,r=!1;return{run(){r||(r=!0,t=new URL(location.href),ot?globalThis.navigation.addEventListener("navigate",o=>{const a=new URL(o.destination.url);a.href!==t.href&&(window.dispatchEvent(new D(a,t)),t=a)},{signal:i.signal}):i.setInterval(()=>{const o=new URL(location.href);o.href!==t.href&&(window.dispatchEvent(new D(o,t)),t=o)},1e3))}}}var st=(u=class{constructor(t,r){f(this,"id");f(this,"abortController");f(this,"locationWatcher",at(this));this.contentScriptName=t,this.options=r,this.id=Math.random().toString(36).slice(2),this.abortController=new AbortController,this.stopOldScripts(),this.listenForNewerScripts()}get signal(){return this.abortController.signal}abort(t){return this.abortController.abort(t)}get isInvalid(){var t;return((t=s.runtime)==null?void 0:t.id)==null&&this.notifyInvalidated(),this.signal.aborted}get isValid(){return!this.isInvalid}onInvalidated(t){return this.signal.addEventListener("abort",t),()=>this.signal.removeEventListener("abort",t)}block(){return new Promise(()=>{})}setInterval(t,r){const o=setInterval(()=>{this.isValid&&t()},r);return this.onInvalidated(()=>clearInterval(o)),o}setTimeout(t,r){const o=setTimeout(()=>{this.isValid&&t()},r);return this.onInvalidated(()=>clearTimeout(o)),o}requestAnimationFrame(t){const r=requestAnimationFrame((...o)=>{this.isValid&&t(...o)});return this.onInvalidated(()=>cancelAnimationFrame(r)),r}requestIdleCallback(t,r){const o=requestIdleCallback((...a)=>{this.signal.aborted||t(...a)},r);return this.onInvalidated(()=>cancelIdleCallback(o)),o}addEventListener(t,r,o,a){var d;r==="wxt:locationchange"&&this.isValid&&this.locationWatcher.run(),(d=t.addEventListener)==null||d.call(t,r.startsWith("wxt:")?k(r):r,o,{...a,signal:this.signal})}notifyInvalidated(){this.abort("Content script context invalidated"),rt.debug(`Content script "${this.contentScriptName}" context invalidated`)}stopOldScripts(){var t;document.dispatchEvent(new CustomEvent(u.SCRIPT_STARTED_MESSAGE_TYPE,{detail:{contentScriptName:this.contentScriptName,messageId:this.id}})),(t=this.options)!=null&&t.noScriptStartedPostMessage||window.postMessage({type:u.SCRIPT_STARTED_MESSAGE_TYPE,contentScriptName:this.contentScriptName,messageId:this.id},"*")}verifyScriptStartedEvent(t){var a,d;const r=((a=t.detail)==null?void 0:a.contentScriptName)===this.contentScriptName,o=((d=t.detail)==null?void 0:d.messageId)===this.id;return r&&!o}listenForNewerScripts(){const t=r=>{!(r instanceof CustomEvent)||!this.verifyScriptStartedEvent(r)||this.notifyInvalidated()};document.addEventListener(u.SCRIPT_STARTED_MESSAGE_TYPE,t),this.onInvalidated(()=>document.removeEventListener(u.SCRIPT_STARTED_MESSAGE_TYPE,t))}},f(u,"SCRIPT_STARTED_MESSAGE_TYPE",k("wxt:content-script-started")),u);function ut(){}function x(i,...t){}const dt={debug:(...i)=>x(console.debug,...i),log:(...i)=>x(console.log,...i),warn:(...i)=>x(console.warn,...i),error:(...i)=>x(console.error,...i)};return(async()=>{try{const{main:i,...t}=nt;return await i(new st("floating-sidebar",t))}catch(i){throw dt.error('The content script "floating-sidebar" crashed on startup!',i),i}})()})();

floatingSidebar;